# S001 — połączenie Obsługi Klienta i Sales Operations

## Wynik

- **Werdykt analityczny:** `CONDITIONAL_GO`
- **Gotowość wdrożeniowa:** `BLOCKED`
- **Liczba bramek blokujących:** `7`
- **Pole `verdict` zachowane dla kompatybilności:** `CONDITIONAL_GO`

Scenariusz może przejść dalej jako projekt warunkowy, ale nie powinien wejść w realizację, dopóki nie zostaną zamknięte krytyczne decyzje dotyczące właściciela reklamacji, raportowania nowej jednostki, SoD/RODO, ciągłości SLA/CSAT, własności danych i wiedzy CRM.

Baseline `BASELINE_2026_07` nie został zmieniony. Analizę zapisano jako logiczny overlay `scenario/S001-customer-operations-test2`.

Overlay jest gałęzią danych scenariusza, a nie fizycznym branchem Git.

## Najważniejsze odkrycie

Najpoważniejszy konflikt nie dotyczy samego połączenia zespołów, lecz działania `ACT002`. Propozycja przeniesienia właściciela reklamacji do nowej roli w Customer Operations koliduje z zatwierdzoną decyzją `DEC002`, która utrzymuje właściciela procesu w Obsłudze Klienta. Dopóki DEC002 nie zostanie formalnie zastąpiona, scenariusz musi zachować wyodrębnioną funkcję Obsługi Klienta i osadzić w niej R003.

## Bezpośrednie skutki

1. **OU003 i OU005 — CRITICAL:** obie jednostki tracą dotychczasowy kształt i różne linie raportowania.
2. **R001 i R002 — HIGH:** konieczna decyzja o liderze Customer Operations i rozdziale odpowiedzialności.
3. **R003 — CRITICAL:** konflikt ACT002 z DEC002; ryzyko utraty właściciela P002.
4. **R006 — HIGH:** kolizja z równoległą inicjatywą I003 dotyczącą własności danych klienta.
5. **P007 / K002 / R005 — CRITICAL:** przebudowa dostępów i obowiązkowy przegląd SoD/RODO.
6. **P006 — HIGH:** wspólny zestaw KPI wymaga nowych definicji, właścicieli i okresu raportowania równoległego.
7. **OU009 — MEDIUM:** mapa ról, szkolenia, redukcja czterech etatów i transfer wiedzy.
8. **G001 — MEDIUM, potencjalnie pozytywny:** scenariusz wspiera cel kosztowy, ale korzyść jest hipotezą i musi być zmierzona.

## Pośrednie skutki

- **P001, M001, M002 i G002 — HIGH:** redukcja zatrudnienia i zmiana struktury mogą obniżyć przepustowość, SLA i CSAT. CSAT >= 82 powinien być bramką przejścia.
- **P002 — CRITICAL:** zmienia się jednostka wykonująca i potencjalnie właściciel; wpływ przechodzi dalej do P005 i P008.
- **P004 i D001 — HIGH:** zmiana OU005 oraz R006 może przerwać proces korekty i własność danych klienta.
- **R004, K005 i A001 — HIGH:** reorganizacja może zwiększyć ryzyko utraty kluczowej wiedzy administratora CRM-X.
- **A001, A002 i A006 — HIGH:** narzędzia nie są wymieniane, ale zmieniają się ich właściciele biznesowi, role i konfiguracja dostępów.
- **D007 i M004 — MEDIUM:** konieczne wersjonowanie KPI i wiarygodne mierzenie oszczędności.
- **P005 i P008 — MEDIUM:** systemy Finansów i Logistyki pozostają, lecz ich handoff zależy od stabilności decyzji reklamacyjnej.

## Główne ścieżki zależności

```text
I001 → OU003 → P001 → M001/M002 → G002
I001 → OU003 → P002 → P005
I001 → OU003 → P002 → P008
I001 → R003 → P002
I001 → P007 → DEC003
I001 → P007 → A006 → D006
I001 → K002 ← P007/DEC003
I001 → OU005 → R006 → P004 → D001
I001 → OU005 → R004 → A001 → K005
ACT004 → P006 → A004/A005 → D007
```

## Decyzje blokujące

1. Rozstrzygnąć konflikt ACT002 z DEC002: zachować właściciela reklamacji w wyodrębnionej funkcji Obsługi Klienta albo formalnie zastąpić DEC002.
2. Zatwierdzić docelową linię raportowania Customer Operations pomiędzy OU002 i OU004 oraz jednego właściciela nowej jednostki.
3. Zatwierdzić przegląd RODO i SoD, docelową macierz dostępów P007 oraz konfigurację IdentityGate przed migracją użytkowników.
4. Zatwierdzić plan ciągłości P001/P002 z warunkami CSAT >= 82, progiem SLA, etapowaniem i rollbackiem przy redukcji czterech etatów.
5. Uzgodnić umiejscowienie R006 i kolejność S001 względem I003, tak aby nie przerwać własności D001 i procesu P004.
6. Zabezpieczyć ciągłość administracji CRM-X i wiedzy R004/K005 przed decyzjami personalnymi.
7. Zatwierdzić wspólny katalog KPI, właścicieli miar i okres raportowania równoległego.

## Kontrole NO_IMPACT

- **P003 / Lead-to-Order B2B — NONE:** proces jest wykonywany przez Sprzedaż OU004, nie przez Sales Operations OU005. S001 może zmienić raportowanie KPI, lecz graf nie uzasadnia redesignu P003.
- **I002 / migracja CRM — NONE:** S001 nie uruchamia migracji i nie zastępuje jej bramek DEC001 oraz C001.
- **C001 / umowa CRM-X — NONE:** restrukturyzacja nie zmienia kontraktu ani dostawcy.
- **A003 / ERP-One — NONE:** możliwy jest wpływ na upstreamowy handoff z reklamacji, ale nie na system finansowy.
- **G003 / wzrost B2B — NONE:** brak ścieżki od I001 do P003/M005/G003; przypisanie korzyści sprzedażowej byłoby niezweryfikowaną hipotezą.

## Warunki przejścia do GO

`GO` staje się uzasadnione dopiero po zamknięciu siedmiu bramek zapisanych w overlayu: właściciel reklamacji, raportowanie, SoD/RODO, jakość obsługi, własność danych, wiedza CRM i KPI. Do tego momentu wynik pozostaje `CONDITIONAL_GO`.

## Uczciwość testu

- analiza została wykonana wyłącznie na plikach pakietu testowego w zakresie merytorycznym scenariusza;
- pakiet nie zawierał odpowiedzi wzorcowych;
- sumy SHA-256 wszystkich plików wejściowych zgadzały się z manifestem;
- `S001_test2_source_index.json` mapuje wszystkie `SRC001–SRC017` na nazwy, pliki, właścicieli, daty i poziom wiarygodności;
- `S001_test2_evidence.json` przechowuje hash wejściowego ZIP-a, manifestu oraz wszystkich artefaktów wynikowych;
- otwarte decyzje pozostają jawnie blokujące i nie są przedstawiane jako rozstrzygnięte.
