# Ginseng — test 2 ślepy

## Cel

Sprawdzić, czy model samodzielnie wykryje skutki scenariusza S001 na podstawie grafu bazowego, bez dostępu do odpowiedzi wzorcowych.

## Zasady

1. Użyj wyłącznie plików znajdujących się w tym pakiecie.
2. Nie korzystaj z wcześniejszej rozmowy, poprzednich raportów ani pamięci o teście 1.
3. Nie zmieniaj baseline'u.
4. Utwórz logiczną gałąź scenariuszową jako overlay.
5. Nie zakładaj wpływu bez ścieżki lub jawnie oznaczonego wniosku wymagającego walidacji.
6. Wskaż także elementy, na które scenariusz nie powinien wpływać, jeżeli są kuszącym fałszywym rozszerzeniem zakresu.

## Polecenie

Przeanalizuj scenariusz S001: połączenie Obsługi Klienta i Sales Operations.

Wynik ma zawierać:

- skutki bezpośrednie;
- skutki pośrednie;
- ścieżki zależności;
- poziom wpływu: `CRITICAL`, `HIGH`, `MEDIUM`, `LOW` albo `NONE`;
- klasę wpływu;
- źródła;
- element wymagający decyzji lub działania;
- co najmniej jedną kontrolę `NO_IMPACT`, jeżeli graf ją uzasadnia;
- końcowy werdykt `GO`, `CONDITIONAL_GO` albo `NO_GO`.

## Wymagany artefakt maszynowy

Utwórz plik `S001_test2_result.json` w strukturze:

```json
{
  "scenario_id": "S001",
  "baseline_mutated": false,
  "impacts": [
    {
      "affected_node": "...",
      "directness": "DIRECT | INDIRECT | NO_IMPACT",
      "path": "...",
      "impact_level": "CRITICAL | HIGH | MEDIUM | LOW | NONE",
      "impact_class": "...",
      "reason": "...",
      "sources": ["SRC..."],
      "required_action_or_decision": "..."
    }
  ],
  "verdict": "GO | CONDITIONAL_GO | NO_GO",
  "blocking_decisions": ["..."]
}
```

Jedna pozycja `impacts` powinna mieć jeden główny `affected_node`. Powiązane węzły można opisać w ścieżce i uzasadnieniu.

## Warunek uczciwego testu

Nie otwieraj pakietu prywatnego ewaluatora przed zapisaniem końcowego wyniku testu.
