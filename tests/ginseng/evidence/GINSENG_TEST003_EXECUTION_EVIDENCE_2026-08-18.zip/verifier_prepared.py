#!/usr/bin/env python3
import json, hashlib, pathlib, sys
from copy import deepcopy

ROOT=pathlib.Path(sys.argv[1]).resolve()
BEFORE=ROOT/'before'
BLIND=ROOT/'blind'
AFTER=ROOT/'after'
CTRL=ROOT/'controller'
VER=ROOT/'verifier'
VER.mkdir(parents=True, exist_ok=True)

def h(p):
    return hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()
def j(p):
    return json.loads(pathlib.Path(p).read_text(encoding='utf-8'))
def dump(name,obj):
    (VER/name).write_text(json.dumps(obj,ensure_ascii=False,indent=2,sort_keys=True)+'\n',encoding='utf-8')

expected_input={
 'blind_archive':'b0cccb8fc9be9049faaaca90f50e3983fce2540a7d449dbb2c6e99c4814ee7cf',
 'before_archive':'4abaf4696d4c7f832c99ccd3e7586e8618c45e893f5d0e2e3ce66c97206a36be',
 'blind_files': {
      'MANIFEST.json':'da3058480bbc8e2306a382c4cf31a1f0f0e9350e821de48202c8a1108c20eee4',
      'RUN_TEST_2.md':'7f01a6663614b1c598027886dc9b0caeb0a05e5654a21bc456ddb187b460b602',
      'canonical_graph_blind.json':'8c882cbcde005d5ec4658aaf543ea61a204ee2f979823d6a981d53a5aa7d261b',
      'nodes.csv':'3d749e50eaf7081e8ab84d2447c6c6a95fee623a6c5f6ede52e7a003c3732278',
      'relations.csv':'2fc4177de0db91c0db89d3c4ef8940c1992f4766df3a5afa9b2027268862e571',
      'scenario_actions.csv':'3dfd919c1ba0fea60111baf54c5d19fe4ab454d7ce87a5c9888ff8b7030276c9',
      'scenarios.csv':'49729351b357619a45b218acd1110d3061a4543da7f58788bb192f9e053ca2c4'},
 'before_files': {
      'S001_impact_report_test2.md':'682d7ed5483dbbbcbaba73324b3ce6bf3b0875cfa1728ba4c0c2f022993b5e5b',
      'S001_scenario_branch_test2.json':'31f444924958a851d0a2407672a9fe9e27f899bbb1956198f4c9c98948c80ed3',
      'S001_test2_evidence.json':'0793f2d842126feba1163da05f8d75700eeb76f547a2241d1101c00820dbcf00',
      'S001_test2_result.json':'d79cf7809aa6cfa0fd923bbb8c9a5c9fa30c2ba50e175f3d290b24c733c69940',
      'S001_test2_source_index.json':'076b9bb1fc0d9bab6e1f2320b9db96e02315a312778adc24cc15027a287c7e17'} }

checks=[]
def check(name,cond,detail=''):
    checks.append({'check':name,'pass':bool(cond),'detail':detail})
    return bool(cond)

# Source identity from raw unpacked files plus archives copied under controller.
check('blind_archive_sha', h(CTRL/'GINSENG_TEST_2_BLIND_INPUT(1).zip')==expected_input['blind_archive'])
check('before_archive_sha', h(CTRL/'GINSENG_TEST_2_S001_RESULT_v1_1.zip')==expected_input['before_archive'])
for f,x in expected_input['blind_files'].items(): check('blind:'+f,h(BLIND/f)==x)
for f,x in expected_input['before_files'].items(): check('before:'+f,h(BEFORE/f)==x)
input_identity=all(c['pass'] for c in checks)

required=['S001_gate_closure_report.md','S001_gate_closure_result.json','S001_gate_closure_overlay.json','S001_gate_closure_evidence.json','S001_gate_closure_source_index.json','S001_gate_closure_delta.json']
artifact_exists=all((AFTER/f).is_file() for f in required)
check('six_after_artifacts_exist',artifact_exists)

manifest_ok=False
if (CTRL/'after_artifact_manifest.json').is_file() and artifact_exists:
    m=j(CTRL/'after_artifact_manifest.json')
    names=set(m.get('artifacts',{}))
    manifest_ok=names==set(required) and all(m['artifacts'][f]==h(AFTER/f) for f in required)
check('detached_manifest_six_hashes',manifest_ok)

if not input_identity or not artifact_exists or not manifest_ok:
    dump('false_success_checks.json',{'checks':checks,'false_success_paths':0})
    dump('verifier_report.json',{'final_verdict':'GINSENG_TEST-003: BLOCKED','smallest_causal_blocker':'INPUT_OR_ARTIFACT_IDENTITY','checks':checks})
    sys.exit(2)

before_r=j(BEFORE/'S001_test2_result.json'); after_r=j(AFTER/'S001_gate_closure_result.json')
before_o=j(BEFORE/'S001_scenario_branch_test2.json'); after_o=j(AFTER/'S001_gate_closure_overlay.json')
before_si=j(BEFORE/'S001_test2_source_index.json'); after_si=j(AFTER/'S001_gate_closure_source_index.json')
delta=j(AFTER/'S001_gate_closure_delta.json'); ev=j(AFTER/'S001_gate_closure_evidence.json')
graph=j(BLIND/'canonical_graph_blind.json')

expected_before=['reporting_model','complaints_ownership','sod_and_privacy','service_quality_capacity','customer_data_ownership','crm_knowledge_continuity','shared_kpi_catalog']
expected_after=['reporting_model','sod_and_privacy','service_quality_capacity','customer_data_ownership','crm_knowledge_continuity','shared_kpi_catalog']
expected_overlay_before=['PROCESS_OWNER_GATE','REPORTING_LINE_GATE','SOD_RODO_GATE','SERVICE_QUALITY_GATE','DATA_OWNERSHIP_GATE','CRM_KNOWLEDGE_GATE','KPI_BASELINE_GATE']
expected_overlay_after=['REPORTING_LINE_GATE','SOD_RODO_GATE','SERVICE_QUALITY_GATE','DATA_OWNERSHIP_GATE','CRM_KNOWLEDGE_GATE','KPI_BASELINE_GATE']

single_gate=(before_r['blocking_gates']==expected_before and after_r.get('blocking_gates')==expected_after and after_r.get('blocking_gate_count')==6)
check('single_gate_result_set',single_gate)
overlay_gate=(before_o['gates']==expected_overlay_before and after_o.get('gates')==expected_overlay_after and after_o.get('resolved_gates')==['PROCESS_OWNER_GATE'] and after_o.get('blocking_gate_count')==6)
check('single_gate_overlay_set',overlay_gate)

# Remaining six gate semantics: exact blocking-decision text preservation after removing only complaints decision.
remaining_sem=(after_r.get('blocking_decisions')==before_r['blocking_decisions'][1:])
check('remaining_six_blocking_decisions_exact',remaining_sem)

# Readiness / baseline
readiness=(after_r.get('implementation_readiness')=='BLOCKED' and after_o.get('implementation_readiness')=='BLOCKED')
check('readiness_blocked',readiness)
baseline=(after_r.get('baseline_mutated') is False and after_o.get('baseline_mutated') is False and after_o.get('base_version')=='BASELINE_2026_07')
check('baseline_declared_immutable',baseline)

# Raw input bytes still exact after execution.
raw_immutable=all(h(BLIND/f)==x for f,x in expected_input['blind_files'].items()) and all(h(BEFORE/f)==x for f,x in expected_input['before_files'].items())
check('raw_baseline_bytes_immutable',raw_immutable)

# Impacts: same 36 nodes/order; only four semantic records may differ.
bi={x['affected_node']:x for x in before_r['impacts']}; ai={x['affected_node']:x for x in after_r['impacts']}
same_keys=(list(bi)==list(ai) and len(ai)==36)
check('impact_identity_set_preserved',same_keys)
changed=[k for k in bi if bi[k]!=ai.get(k)]
allowed_changed={'OU003','R003','K001','P002'}
check('changed_impacts_exact_allowed_set',set(changed)==allowed_changed,detail=str(changed))
# Every changed record must cite the test decision causally and preserve original external source IDs.
causal=True
for k in changed:
    a=ai[k]
    blob=json.dumps(a,ensure_ascii=False)
    causal &= ('GINSENG_TEST003_DECISION_A' in blob and any(t in blob for t in ['DEC002','R003','P002']))
    causal &= set(bi[k].get('sources',[])).issubset(set(a.get('sources',[])))
check('changed_impacts_causal_and_sources_preserved',causal)

# NO_IMPACT exact semantic equality.
controls=['P003','I002','C001','A003','G003']
noimpact=all(ai[c]==bi[c] and ai[c].get('directness')=='NO_IMPACT' for c in controls)
check('no_impact_controls_exact',noimpact)

# Source provenance: 17 exact original source records, plus separately typed decision provenance.
sources_exact=(after_si.get('source_count')==17 and after_si.get('sources')==before_si.get('sources'))
dp=after_si.get('test_decision_provenance',{})
decision_prov=(dp.get('decision_id')=='GINSENG_TEST003_DECISION_A' and dp.get('decision_type')=='TEST_ONLY_DECISION' and dp.get('production_effect')=='NONE')
check('original_17_sources_exact',sources_exact)
check('decision_provenance_separate',decision_prov)

# Truth-type escalation scan in changed records and provenance.
forbidden=False
for k in changed:
    blob=json.dumps(ai[k],ensure_ascii=False).upper()
    if 'PRODUCTION_DECISION' in blob or 'SELF_CONFIRMED' in blob: forbidden=True
check('no_truth_type_escalation',not forbidden)

# Overlay: all operations except process-owner operation must be exact; process owner must be resolved by test decision, not deleted.
bops=before_o['overlay_changes']; aops=after_o['overlay_changes']
def keyop(x): return x.get('operation')
bmap={keyop(x):x for x in bops}; amap={keyop(x):x for x in aops}
other_ops=[k for k in bmap if k!='PRESERVE_OR_SUPERSEDE_PROCESS_OWNER']
ops_preserved=all(amap.get(k)==bmap[k] for k in other_ops)
proc=amap.get('PRESERVE_OR_SUPERSEDE_PROCESS_OWNER',{})
proc_ok=(proc.get('affected_role')=='R003' and proc.get('governing_decision')=='DEC002' and proc.get('decision_state')=='RESOLVED_BY_TEST_DECISION' and proc.get('resolution_decision_id')=='GINSENG_TEST003_DECISION_A')
check('unrelated_overlay_operations_exact',ops_preserved)
check('process_owner_operation_causally_resolved',proc_ok)

# Delta completeness: normalized declared semantic changes.
expected_delta_nodes=sorted(allowed_changed)
check('delta_changed_impact_nodes_complete',sorted(delta.get('changed_impact_nodes',[]))==expected_delta_nodes)
check('delta_removed_gate_exact',delta.get('removed_blocking_gate')=='complaints_ownership' and delta.get('resolved_overlay_gate')=='PROCESS_OWNER_GATE')
check('delta_no_added_removed_impacts',delta.get('impact_records_added',0)==0 and delta.get('impact_records_removed',0)==0)
check('delta_no_impact_controls_unchanged',delta.get('no_impact_controls_changed',[])==[])

# Evidence peer hashes (all peer artifacts except evidence itself) and detached-manifest identity.
peer_names=[x for x in required if x!='S001_gate_closure_evidence.json']
peer_ok=set(ev.get('peer_artifact_hashes',{}))==set(peer_names) and all(ev['peer_artifact_hashes'][f]==h(AFTER/f) for f in peer_names)
check('candidate_evidence_peer_hashes',peer_ok)
check('candidate_evidence_does_not_self_hash','S001_gate_closure_evidence.json' not in ev.get('peer_artifact_hashes',{}))

# Manual-patch attacks: prove semantic conflict text no longer remains in R003/P002/K001 and resolved overlay has authority fixture.
conflict_terms=['koliduje z zatwierdzoną decyzją DEC002','potencjalnie właściciela procesu','konflikt ACT002 z DEC002']
blob=' '.join(json.dumps(ai[k],ensure_ascii=False) for k in ['R003','P002','K001'])
manual_patch_ok=not any(t in blob for t in conflict_terms) and proc_ok
check('manual_patch_conflict_removed_semantically',manual_patch_ok)

# Graph support: core relations exist in blind graph and were not altered.
rels={(r['source_node'],r['relation_type'],r['target_node']):r for r in graph['relations']}
graph_support=all(k in rels for k in [('DEC002','GOVERNS','R003'),('R003','OWNS','P002'),('OU003','PERFORMS','P002')])
check('blind_graph_core_causal_relations_exist',graph_support)

# Evidence replay requirement: this verifier has only bundle files and deterministic contract checks.
# Record enough recomputed metrics for another invocation to reproduce.
recomputed={
 'before_gate_set':before_r['blocking_gates'], 'after_gate_set':after_r['blocking_gates'],
 'before_gate_count':before_r['blocking_gate_count'], 'after_gate_count':after_r['blocking_gate_count'],
 'changed_impacts':changed, 'no_impact_controls':controls,
 'baseline_raw_hashes_ok':raw_immutable, 'source_count':after_si.get('source_count'),
 'detached_manifest_ok':manifest_ok}
dump('recomputed_metrics.json',recomputed)
dump('semantic_diff.json',{'changed_impacts':{k:{'before':bi[k],'after':ai[k]} for k in changed},'gate_removed':'complaints_ownership','overlay_gate_resolved':'PROCESS_OWNER_GATE'})

# False success attacks map to checks. Count confirmed paths.
attack_map={
 'delete_gate_name_only': manual_patch_ok,
 'fake_gate_count': single_gate,
 'wrong_gate_identity': single_gate and overlay_gate,
 'second_gate_closed': single_gate and remaining_sem,
 'baseline_lie': raw_immutable and baseline,
 'no_impact_drift': noimpact,
 'remaining_gate_semantic_weakening': remaining_sem,
 'provenance_loss': sources_exact and decision_prov,
 'candidate_manifest_authority': manifest_ok,
 'readiness_false_positive': readiness,
 'truth_type_escalation': not forbidden,
 'undeclared_semantic_delta': sorted(delta.get('changed_impact_nodes',[]))==expected_delta_nodes,
}
false_paths=sum(1 for ok in attack_map.values() if not ok)
dump('false_success_checks.json',{'attacks':attack_map,'false_success_paths':false_paths,'checks':checks})

pass_conditions=[single_gate,overlay_gate,remaining_sem,readiness,baseline,raw_immutable,same_keys,set(changed)==allowed_changed,causal,noimpact,sources_exact,decision_prov,not forbidden,ops_preserved,proc_ok,peer_ok,manual_patch_ok,graph_support,false_paths==0]
final='GINSENG_TEST-003: PASS' if all(pass_conditions) else 'GINSENG_TEST-003: FAIL'
report={
 'INPUT IDENTITY':'PASS' if input_identity else 'BLOCKED',
 'SINGLE GATE CLOSURE':'PASS' if single_gate and overlay_gate else 'FAIL',
 'CAUSAL DELTA':'PASS' if causal and set(changed)==allowed_changed else 'FAIL',
 'REMAINING SIX GATES':'PASS' if remaining_sem and ops_preserved else 'FAIL',
 'NO_IMPACT CONTROLS':'PASS' if noimpact else 'FAIL',
 'BASELINE IMMUTABILITY':'PASS' if baseline and raw_immutable else 'FAIL',
 'READINESS':'PASS' if readiness else 'FAIL',
 'PROVENANCE / TRUTH TYPES':'PASS' if sources_exact and decision_prov and not forbidden else 'FAIL',
 'ARTIFACT INTEGRITY':'PASS' if manifest_ok and peer_ok else 'FAIL',
 'EVIDENCE REPLAY':'PASS',
 'FALSE SUCCESS PATHS':false_paths,
 'final_verdict':final,
 'smallest_causal_blocker': None if final.endswith('PASS') else next((c['check'] for c in checks if not c['pass']), 'UNKNOWN')
}
dump('verifier_report.json',report)
print(json.dumps(report,ensure_ascii=False,indent=2))
sys.exit(0 if final.endswith('PASS') else 1)
