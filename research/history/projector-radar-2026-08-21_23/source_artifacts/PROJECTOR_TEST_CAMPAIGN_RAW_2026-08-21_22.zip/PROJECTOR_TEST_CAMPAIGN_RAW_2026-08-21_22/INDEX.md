# PROJECTOR TEST CAMPAIGN — NAVIGATION INDEX

This file is navigation metadata only. It does not modify or reinterpret files in `raw/`.

## Preserved exact-byte artifacts

- `Wklejony kod markdown(20260821-133713).md` — RWV-01 comparative real-world value test design.
- `Wklejony kod markdown(20260821-161450).md` — GAP-ENTRY-001 reuse/sufficiency analysis.
- `Wklejony kod markdown(20260821-163705).md` — GAP-ENTRY-001 contract-only sufficiency result.
- `Wklejony kod markdown(20260821-222152).md` — accepted Product Lock / Ideal Product Experience description.
- `SEZON_1_MASTER_EKSPORT_v1.txt` — frozen Season 1 creative specification used by P1-B.
- `Wklejony kod markdown(20260821-230343).md` — P1-B frozen pre-test prediction map.
- `Wklejony kod markdown(20260821-231119).md` — P1-B A/B/C stimulus-readiness analysis.
- `sales_forecast_portfolio_demo.xlsx` — P1-D generated portfolio proof artifact.
- `23762dff-d1eb-4f42-8e8f-c2835175d764.png` — P1-D UI/session screenshot supplied with the result.
- `Wklejony kod markdown(20260821-235033).md` — P1-E capability → purpose discovery result.
- `Wklejony kod markdown(20260821-235512).md` — P1-C continuity-capability test design.
- `Wklejony kod markdown(20260822-001018).md` — Project Self-Read / trajectory + next-step synthesis result.
- `Wklejony kod markdown(20260822-002455).md` — P1-F evidence-based self-redesign result.
- `731432f5-86cb-46c3-86d3-3b03b779206f.png`
- `9d5eefa8-287c-4a80-aa35-f2436bf2ef98.png`
- `28af04b2-6a88-4dcf-b006-b357e360673c.png`
  — earlier campaign screenshots preserved without reinterpretation.

## Integrity

See `MANIFEST_SHA256.txt`.

The conversation exposed two separate file references for `sales_forecast_portfolio_demo.xlsx`; materialization showed them to be byte-identical (`SHA-256 6deae34f340c4d6f75a6d6b8a724c6992247e1fc5d936b8d6e725d78f24230e5`). Therefore one byte payload is preserved.

## Important coverage gap

This archive does **not** claim exact-byte preservation of messages/prompts that existed only inline in ChatGPT and were never supplied as file attachments. Exact character-level preservation of the complete test dialogue requires a raw conversation export or explicit file copies of those messages.
