Tak. Bounded detour kończy się na **wyborze stimulusa**, bez produkowania go i bez ruszania Prediction Map.

Punktem odniesienia pozostaje Episode 1, bo frozen spec sama określa go jako najbardziej natychmiastowe wejście w format: prosty konflikt, szybkie ujawnienie emocji przez liść, błędna reakcja, chaos i aktywna naprawa. W samym odcinku krytyczne są też ruchome stany liścia, chwianie wieży, rozsypka, cisza po failu i czynności naprawcze. 

# A. NARRATED / STORYBOARD READING

Za uczciwy wariant A uznaję **zamknięte nagranie**, nie dorosłego czytającego na żywo. Live reading wprowadzałby różne tempo, intonację i reakcje na każde dziecko.

### 1. TEST COVERAGE

A może uczciwie sprawdzić przede wszystkim:

- **E1-P1 — conflict comprehension:** czy dziecko rozumie spór o czerwony klocek; 
- **E1-P3 — memory target**, ale tylko jako pamięć **statycznego/ilustrowanego obrazu** rozsypki; 
- **E1-P4 — repair comprehension:** oddanie klocka, zebranie elementów, odbudowa; 
-  częściowo **E1-P5 / PM-S03 — leaf cue**, jeśli wszystkie istotne zmiany koloru/kształtu liścia są jawnie pokazane na storyboardach; 
- **PM-S01 — concrete before abstract**; 
-  częściowo **PM-S02 — image before explanation**; 
- **PM-S07 — active repair**; 
- **PM-S08 — BEFORE → AFTER**; 
- **PM-S09 — relational closure**; 
-  częściowo **PM-S10 — signature-image recall**. 

Można również zanotować spontaneous continuation, ale będzie to:

> chęć zobaczenia/usłyszenia **kolejnej historii w tej formie**

a nie jeszcze silny dowód atrakcyjności serialu audiowizualnego.

### 2. NOT COVERED

Pilot 1 z A pozostawia jako `NOT TESTED IN PILOT 1`:

- **E1-P2 — czy rozsypka jest lokalnym attention/reaction peak** w serialowym sensie; 
-  ruchową część **E1-P5**; 
- **PM-S04 — eskalacja → dynamiczny payoff**; 
- **PM-S05 — physical silly fail jako attention peak**; 
-  uczciwy test **PM-S06 — funkcji czasowej pauzy po chaosie**; 
-  reakcję na dokładne tempo ruchu; 
-  reakcję na przejścia stanu liścia w czasie; 
-  audiovisual attention transitions. 

Predykcje pozostają zamrożone. Po prostu ich nie testujemy.

### 3. CONFOUNDERS

Największy problem A jest metodologiczny, nie estetyczny.

Forma wprowadza:

-  atrakcyjność konkretnego głosu narratora; 
-  interpretację aktorską; 
-  konieczność **opisania słowami części tego, co w serialu miało być pokazane obrazem**; 
-  abstrakcyjność nieruchomego storyboardu; 
-  skoki między obrazami zamiast ciągłego działania; 
-  ryzyko, że narration sama poda dziecku relację przyczynową, którą chcieliśmy sprawdzić. 

To szczególnie kłóci się z frozen założeniem „obraz przed objaśnieniem”. 

### 4. COST / SCOPE

Najmniejszy rzeczywisty build:

-  komplet prostych plansz obejmujących wszystkie story-critical states; 
-  widoczny czerwony klocek i funkcję środka/bramy; 
-  kolejne stany liścia; 
-  kilka plansz rozsypki zamiast jednej; 
-  nagrany i zamrożony dialogue/narration track; 
-  eksport do jednego pliku video. 

Rząd wielkości przy tworzeniu materiału od zera: **około pół–1,5 dnia prostego wykonania**, bez polishu.

To zdecydowanie najtańszy wariant.

### 5. INFORMATION VALUE

**MEDIUM.**

Bardzo dobry stosunek koszt/wiedza dla:

> „czy dziecko w ogóle rozumie tę historię?”

Wyraźnie słabszy dla:

> „czy formalne właściwości serialu działają tak, jak przewidywaliśmy?”

Bo część tych właściwości jest właśnie temporalna i ruchowa.

### 6. STIMULUS IDENTITY / FREEZE COST

**VERY LOW.**

Najlepiej zamrozić go jako jeden plik video:

-  visual sequence — **YES** 
-  dialogue/narration — **YES** 
-  timing plansz — **YES** 
-  leaf state — **YES, statyczne stany** 
-  leaf behavior in motion — **NO** 
-  sound — **dialogue/narration only** 
-  version — checksum/nazwa wersji 

Bardzo wysoka repeatability.

---

# B. ANIMATIC / STORY REEL

Przez B rozumiem **minimalny timed audiovisual representation scenariusza**, nie „tanią animację”.

Kluczowa różnica wobec A: dziecko **widzi zdarzenia rozgrywające się w czasie**, zamiast dostawać ich dodatkowy opis.

### 1. TEST COVERAGE

B pokrywa praktycznie cały wartościowy zestaw Pilot-1 dla Episode 1:

**Direct / strong:**

- **E1-P1** — rozumienie konfliktu; 
- **E1-P2** — reakcja wokół chwiania/rozsypki; 
- **E1-P3** — prerejestrowany memory target; 
- **E1-P4** — zrozumienie aktywnej naprawy; 
- **PM-S01** — konkretny problem; 
- **PM-S04** — eskalacja → payoff; 
- **PM-S05** — fizyczny silly fail; 
- **PM-S07** — aktywna naprawa; 
- **PM-S08** — błędne zachowanie → poprawione zachowanie; 
- **PM-S09** — powrót do wspólnego działania; 
- **PM-S10** — signature-image recall. 

**Partial, zgodnie z już zamrożoną epistemologią:**

- **E1-P5 / PM-S03** — czy dziecko zauważa/używa zachowania liścia; 
- **PM-S02** — obraz poprzedza werbalne domknięcie; 
- **PM-S06** — co dzieje się z uwagą w stopie po chaosie. 

B nadal **nie dowodzi**, że to liść/pauza/obraz *spowodowały* zrozumienie. Ale pozwala wreszcie obserwować predicted phenomena w formie zgodnej z ich strukturą.

### 2. NOT COVERED

`NOT TESTED IN PILOT 1` pozostają:

- **PM-S11** — transfer tego samego formatu między różnymi emocjami; wymaga wielu odcinków; 
- **PM-S12** — E1/E2 jako bardziej natychmiastowe niż późniejsze epizody; wymaga porównania; 
-  jakiekolwiek causal claims typu „liść powoduje comprehension”; 
-  wpływ finalnego animation performance; 
-  wpływ finalnych głosów; 
-  wpływ muzyki; 
-  wpływ finalnego sound designu; 
-  wpływ production polish; 
-  reakcja na dokładną finalną estetykę serialu. 

I dobrze. Pilot 1 nie musi wiedzieć wszystkiego.

### 3. CONFOUNDERS

B wprowadza nowe zmienne:

-  czytelność rough drawings; 
-  timing animaticu; 
-  wybór wielkości/kolejności kadrów; 
-  scratch voice performance; 
-  jakość minimalnego motion; 
-  sposób przedstawienia chwiania i rozsypki; 
-  tempo zmian liścia. 

To realne confoundery.

Ale jest ich **znacznie mniej niż w C**, a większość odpowiada dokładnie formalnym własnościom, które P1-B chce zacząć testować.

### 4. COST / SCOPE

Minimalny B nie wymaga:

-  rigów; 
-  finalnych modeli; 
-  pełnej animacji; 
-  lip-syncu; 
-  muzyki; 
-  compositingu; 
-  finalnych backgroundów; 
-  FX polishu. 

Wymaga:

-  jednego Episode 1; 
-  rough visual states dla wszystkich story-critical actions; 
-  więcej niż jednej pozy tam, gdzie **ruch sam niesie znaczenie**; 
-  szczególnie czytelnego: 
  -  przytulenia czerwonego klocka, 
  -  umieszczenia go na czubku, 
  -  chwiania, 
  -  przejścia klocka przez środek, 
  -  rozbiegających się klocków, 
  -  ciszy, 
  -  oddania i odbudowy; 
-  jawnych stanów i przejść liścia; 
-  dokładnego dialogue track; 
-  locked edit. 

Przy budowaniu od zera rozsądny minimalny rząd wielkości to **około 1–3 prostych dni roboczych**, zależnie od tego, czy istnieją już jakiekolwiek character/background assets.

Nie jest to production pipeline. To jeden eksperymentalny stimulus.

### 5. INFORMATION VALUE

**HIGHEST INFORMATION / COST.**

B dociera do granicy, która jest dla P1-B najcenniejsza:

> zachowuje historię jako **sekwencję audiowizualnych zdarzeń w czasie**, ale nie dokłada jeszcze warstwy polishu, której wpływu nie próbujemy obecnie mierzyć.

Dostajemy pierwszą sensowną odpowiedź zarówno na comprehension, jak i na **moment-to-moment response**.

### 6. STIMULUS IDENTITY / FREEZE COST

**LOW.**

Po ukończeniu eksportujemy dokładnie jeden plik video.

Możemy zamrozić:

-  visual sequence — **YES** 
-  dialogue — **YES** 
-  timing — **YES** 
-  leaf color — **YES** 
-  leaf shape/movement — **YES** 
-  story-critical motion — **YES** 
-  sound — **YES, dokładnie określony zakres** 
-  version — **YES** 

To daje każdemu dziecku ten sam bodziec bez udziału osoby prowadzącej w jego wykonaniu.

---

# C. FULLER AUDIOVISUAL PROTOTYPE

C oznacza materiał zbliżający się już do faktycznego odcinka: płynniejsza animacja, character performance, bardziej finalne art/voice/sound/edit.

### 1. TEST COVERAGE

Pokrywa wszystko, co B, a dodatkowo pozwala uczciwiej obserwować:

-  attention response wobec faktycznego ruchu; 
-  reakcję na pełniejszy physical comedy timing; 
-  ekspresję liścia w kontekście character animation; 
-  wpływ głosu/dialogue performance; 
-  wpływ event SFX; 
-  jeśli je dodamy — muzyki i pełnego soundscape; 
-  większą ecological validity pytania „czy dziecko chce zobaczyć więcej tego serialu?”. 

Pod względem **absolute coverage** C wygrywa.

### 2. NOT COVERED

Nadal nie rozwiązuje:

- **PM-S11** bez innych odcinków; 
- **PM-S12** bez porównań; 
-  causal attribution między liściem, dialogiem, ruchem, dźwiękiem itd.; 
-  pytania, czy AI miało poprawny historyczny rationale; 
-  testu pattern recognition A. 

Więcej produkcji ≠ automatycznie więcej epistemicznej rozdzielczości.

### 3. CONFOUNDERS

Tu pojawia się paradoks.

C jest bliższe finalnemu serialowi, ale przy pierwszym teście wprowadza najwięcej alternatywnych wyjaśnień:

-  atrakcyjność character designu; 
-  jakość animation acting; 
-  tempo montażu; 
-  głosy; 
-  intonacja; 
-  comedy performance; 
-  muzyka; 
-  SFX; 
-  miks; 
-  kolor; 
-  lighting; 
-  camera; 
-  FX; 
-  poziom polishu. 

Jeżeli dziecko nagle ożyje podczas rozsypki, możemy mieć większy problem z odpowiedzią:

> czy zadziałała struktura przewidziana przez model, czy po prostu świetny dźwięk i performance?

To nie dyskwalifikuje C. Po prostu **na Pilot 1 jest to przedwczesna utrata prostoty eksperymentu**.

### 4. COST / SCOPE

Minimum jest wielokrotnie większe niż B.

Trzeba podjąć i zamrozić decyzje dotyczące:

-  wyglądu postaci; 
-  środowiska; 
-  płynności/ruchu; 
-  animation performance; 
-  voice performance; 
-  audio; 
-  edit/compositing. 

Bez istniejących assetów łatwo przechodzi to z **kilku dni w tydzień+ pracy**, nawet jeśli nadal nazywamy rezultat „prototype”.

To zaczyna niebezpiecznie zbliżać bounded detour do production detour.

### 5. INFORMATION VALUE

**HIGHEST ABSOLUTE INFORMATION, LOWER MARGINAL VALUE / COST FOR PILOT 1.**

C ma sens, kiedy pytanie brzmi już:

> „czy ta faktyczna realizacja odcinka działa?”

Pierwsze pytanie P1-B jest wcześniejsze:

> „czy prediction structure przeżywa pierwszy kontakt z prawdziwym dzieckiem?”

Do tego C jest większe niż trzeba.

### 6. STIMULUS IDENTITY / FREEZE COST

Gotowy C można zamrozić bardzo dobrze — jeden finalny plik.

Problem nie leży w technicznym freeze po eksporcie.

Problemem jest **koszt dojścia do tożsamości stimulusa**: trzeba wcześniej zdecydować mnóstwo rzeczy, których frozen creative spec nie rozstrzyga.

---

# PORÓWNANIE

| **A Storyboard readingB Animatic/story reelC Fuller prototype** |                                  |                               |                                  |
| --------------------------------------------------------------- | -------------------------------- | ----------------------------- | -------------------------------- |
| Conflict comprehension                                          | **HIGH**                         | **HIGH**                      | **HIGH**                         |
| Repair comprehension                                            | **HIGH**                         | **HIGH**                      | **HIGH**                         |
| Free recall                                                     | **MED/HIGH**                     | **HIGH**                      | **HIGH**                         |
| Dynamic attention                                               | **LOW / invalid for key claims** | **HIGH enough**               | **HIGH**                         |
| Silly-fail response                                             | **LOW/PARTIAL**                  | **HIGH enough**               | **HIGH**                         |
| Timing/pause                                                    | **WEAK**                         | **YES**                       | **YES**                          |
| Leaf state                                                      | **STATIC/PARTIAL**               | **DYNAMIC/PARTIAL inference** | **DYNAMIC/PARTIAL inference**    |
| Final AV appeal                                                 | **NO**                           | **NO**                        | **PARTIAL/HIGH**                 |
| New confounders                                                 | LOW–MED                          | **MED**                       | **HIGH**                         |
| Build scope                                                     | **LOW**                          | **LOW–MED**                   | **HIGH**                         |
| Freeze repeatability                                            | **VERY HIGH**                    | **VERY HIGH**                 | **VERY HIGH after costly build** |
| Information / cost                                              | MEDIUM                           | **HIGHEST**                   | MEDIUM                           |
| Risk of production detour                                       | VERY LOW                         | **LOW**                       | **HIGHER**                       |

---

# RECOMMENDED PILOT-1 STIMULUS

## **B — MINIMAL LOCKED ANIMATIC / STORY REEL OF EPISODE 1**

Nie fuller prototype.

Nie narrated reading.

### WHY

Bo jest to **najmniejszy stimulus, który zachowuje te właściwości frozen modelu, których A już metodologicznie nie potrafi uczciwie reprezentować**:

**sequence + motion + timing + physical causality + pause + dynamic leaf behavior.**

A zatrzymuje się tuż przed nimi.

C idzie znacznie dalej niż trzeba.

B trafia w środek.

Frozen E1 został skonstruowany właśnie jako sekwencja: wspólny klocek → zawłaszczenie → coraz wyższa/chwiejąca się wieża → fizyczna rozsypka → cisza → samonazwanie → aktywna naprawa → wspólne domknięcie. Liść również przechodzi przez konkretne kolejne stany. 

---

# PREDICTIONS COVERED

Pilot 1 / B:

**COVERED / DIRECTLY TESTABLE**

-  E1-P1 
-  E1-P2 
-  E1-P3 
-  E1-P4 
-  PM-S01 
-  PM-S04 
-  PM-S05 
-  PM-S07 
-  PM-S08 
-  PM-S09 
-  PM-S10 

**PARTIALLY TESTABLE**

-  E1-P5 / PM-S03 
-  PM-S02 
-  PM-S06 
-  spontaneous continuation as reaction to **animatic format**, not yet final serial 

---

# PREDICTIONS LEFT UNTESTED

**STILL FROZEN — NOT TESTED IN PILOT 1**

-  PM-S11 — emotional transfer across episodes; 
-  PM-S12 — relative immediacy E1/E2 vs later material; 
-  final production audiovisual appeal; 
-  music response; 
-  final voice-performance response; 
-  final-animation response; 
-  causal claim that leaf itself improves comprehension; 
-  causal claim that pause itself improves comprehension; 
-  any universal claim about children 3–5; 
-  Pattern Recognition A relative to original reference corpus. 

Nic z tego nie zostaje osłabione ani przepisane.

---

# NEW CONFOUNDERS

Dla wybranego B trzeba jawnie zapisać:

1. **rough-art readability**; 
2. **animatic timing**; 
3. **scratch voice performance**; 
4. **minimal-motion execution**; 
5. **leaf transition execution**; 
6. **brak finalnego polishu**. 

To są confoundery Pilot 1, nie findingi o dzieciach.

---

# MINIMUM BUILD REQUIRED

Tylko **Episode 1**.

Jedno linearne video zawierające:

-  wszystkie frozen sceny i dialogi; 
-  żadnego nowego narratora; 
-  rough, ale jednoznaczne postaci/obiekty; 
-  czerwony klocek zawsze identyfikowalny; 
-  wspólny środek/bramę czytelną wizualnie; 
-  story-critical motion; 
-  rzeczywiste chwianie wieży; 
-  rzeczywisty ruch czerwonego klocka przez środek; 
-  rozbiegnięcie klocków; 
-  rzeczywistą zamrożoną długość ciszy; 
-  widoczne akty naprawy; 
-  wszystkie frozen stany/przejścia liścia. 

**Nie wymaga:** final art, lip-sync, muzyki, FX polish, riggingu ani pełnej animacji.

---

# FREEZE REQUIREMENTS

Dla `P1B_PILOT1_STIMULUS_E01_ANIMATIC_v1` zamrozić jednocześnie:

**Visual sequence:** exact exported frames/shots
 **Dialogue:** dokładnie frozen dialogue, bez dopisywania narracji
 **Timing:** jeden locked edit; zero ręcznego pause/play podczas badania
 **Leaf behavior:** kolor + kształt + timing zmian jawnie określone w materiale
 **Sound:** **dialogue only** w Pilot 1; bez muzyki i dekoracyjnego SFX
 **Voice:** ta sama zamrożona scratch performance dla każdego dziecka
 **Stimulus version:** immutable export + jednoznaczne ID/version/hash
 **Playback:** ten sam plik od początku do końca

Wybór **dialogue only** jest celowy: zachowuje dziecku dostęp do istniejącego dialogu, ale nie pozwala jeszcze muzyce czy comedy SFX „wygrać eksperymentu” za strukturę.

To oznacza też:

> audio-specific prediction = **NOT TESTED IN PILOT 1**

nie „failed”.

---

# WHAT EVIDENCE WOULD CHANGE THIS RECOMMENDATION

Rekomendację **B** zmieniłyby przede wszystkim cztery rzeczy:

**→ A**, jeśli okaże się, że celem najbliższego pilota jest świadomie tylko **comprehension + recall**, a moment-to-moment attention / physical payoff zostają jawnie odłożone. Wtedy animatic byłby niepotrzebnym kosztem.

**→ C**, jeśli istnieje już niemal gotowy prototyp Episode 1, który można zamrozić **przy marginalnym koszcie porównywalnym z B**. Wtedy argument kosztowy przeciw C praktycznie znika.

**→ C**, jeśli odkryjemy, że kluczowa dla najbliższego TODO predykcja zależy bezpośrednio od performance, płynnej animacji albo dźwięku, których animatic nie może reprezentować.

**→ A**, jeśli minimalny animatic niespodziewanie wymaga uruchomienia faktycznego production pipeline zamiast prostego jednorazowego reel. Wtedy naruszałby ustalony scope detouru.

Na obecnych dowodach:

> **RECOMMENDED PILOT-1 STIMULUS = B — MINIMAL LOCKED ANIMATIC / STORY REEL, EPISODE 1.**

To daje pierwszy metodologicznie uczciwy kontakt **frozen prediction model → real child** bez udawania, że testujemy finalny serial, i bez budowania finalnego serialu przed poznaniem pierwszego wyniku.