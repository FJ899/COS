Product lock przyjęty. Poniżej traktuję go jako wzorzec doświadczenia, nie specyfikację systemu.

## Idealne Product Experience Projektora

1. **Wejście — „mam pomysł / problem”**

   **Human robi:** mówi naturalnie, co ma w głowie. Może to być nieuporządkowany pomysł, problem, obserwacja, potrzeba albo „chcę coś zrobić, ale jeszcze nie wiem jak”. Nie przygotowuje briefu ani specjalnego handoffu.

   **Projektor powinien wiedzieć:** czy istnieje już kontekst projektu, co jest wiedzą zastaną, czego jeszcze nie wiadomo oraz które elementy wypowiedzi są faktem, intencją, hipotezą albo tylko pierwszym pomysłem na rozwiązanie.

   **Projektor robi:** pomaga oddzielić problem od pierwszego rozwiązania. Rekonstruuje: co Human chce osiągnąć, dlaczego to ma znaczenie, jaka jest obecna rzeczywistość, co przeszkadza i czego jeszcze nie wiemy. Jeżeli dostrzega inne możliwe interpretacje problemu, pokazuje je zamiast automatycznie przyjmować pierwszą.

   **Human decision / authority:** potrzebna tylko wtedy, gdy różne interpretacje prowadzą do różnych celów. Projektor może proponować sformułowanie celu, ale nie może go ustanowić.

   **Po wykonaniu pozostaje:** roboczo nazwany problem, kontekst oraz wyraźne rozróżnienie między `GOAL` a pierwszym pomysłem na `HOW`.
2. **Ustalenie kierunku — „po co właściwie to robimy?”**

   **Human robi:** akceptuje, poprawia albo odrzuca proponowane `GOAL`, `DONE`, priorytet i istotne ograniczenia.

   **Projektor powinien wiedzieć:** co jest Human-owned celem, po czym Human rozpozna sukces oraz czego produkt/projekt świadomie teraz nie próbuje osiągnąć.

   **Projektor robi:** pomaga zrobić kryterium DONE wystarczająco konkretne, aby później można było oceniać nowe pomysły i lokalne problemy względem niego. Może wskazać ukryte napięcia, np. „szybkość kontra kontrola”, ale nie rozstrzyga ich normatywnie.

   **Human decision / authority:** tutaj jest obowiązkowa. To jeden z fundamentalnych Human gates.

   **Po wykonaniu pozostaje:** jawny `GOAL / DONE / PRIORITY / CONSTRAINTS`, z informacją, że są Human-owned.
3. **Orientacja — „gdzie naprawdę jesteśmy?”**

   **Human robi:** niczego nie rekonstruuje ręcznie, jeśli Projektor może odzyskać to z dostępnych dowodów. Dostarcza tylko brakujące fakty, których naprawdę nie da się ustalić inaczej.

   **Projektor powinien wiedzieć:** jaki jest aktualny stan projektu na podstawie dowodów, a nie własnej narracji. Powinien odróżniać co najmniej:
    `fakt`, `Human decision`, `working hypothesis`, `proposal`, `wykonany rezultat`, `niezweryfikowane twierdzenie`, `parking`, `otwarta niewiadoma`.

   **Projektor robi:** buduje evidence-grounded working understanding. Jeżeli źródła są zgodne — kontynuuje. Jeżeli są sprzeczne — pokazuje konflikt. Nie skleja sprzeczności w wygodną historię.

   **Human decision / authority:** potrzebna dopiero wtedy, gdy sprzeczności nie da się rozstrzygnąć istniejącą authority albo wybór sam zmieniałby znaczenie projektu.

   **Po wykonaniu pozostaje:** aktualny obraz projektu razem z niepewnościami. Projektor wie również **dlaczego** projekt znalazł się w tym miejscu.
4. **Poszerzenie pola decyzji — „jakie naprawdę mamy drogi?”**

   **Human robi:** opisuje preferencje, ograniczenia lub reaguje na przedstawione możliwości. Nie musi sam generować wszystkich alternatyw.

   **Projektor powinien wiedzieć:** jakie rozwiązanie Human obecnie rozważa, jakie są jego założenia oraz jakie cechy musi mieć dobry wynik względem GOAL/DONE.

   **Projektor robi:** aktywnie szuka **materialnie różnych** dróg, a nie kosmetycznych wariantów tej samej koncepcji. Może zakwestionować założenie, zmienić poziom abstrakcji albo pokazać prostszą drogę do tego samego celu. Porównuje opcje względem Human-owned kryteriów.

   Nie mówi: „to jest właściwy cel”.

   Może powiedzieć: „przy Twoim celu ta droga wygląda najlepiej, ponieważ…”.

   **Human decision / authority:** wybór normatywnego kierunku należy do Human, kiedy istnieje rzeczywiste rozdroże.

   **Po wykonaniu pozostaje:** wybrany kierunek, jego uzasadnienie i najważniejsze alternatywy, które świadomie nie zostały wybrane. Rekomendacja AI i decyzja Human pozostają rozróżnione.
5. **Ustalenie najbliższego realnego rezultatu**

   **Human robi:** nie zarządza mikrotaskami. Interweniuje tylko wtedy, gdy proponowany rezultat zmieniałby zakres, priorytet albo znaczenie projektu.

   **Projektor powinien wiedzieć:** jaki następny rezultat najbardziej przybliża aktualne DONE oraz jakie warunki muszą zostać spełnione, żeby uznać go za rzeczywiście osiągnięty.

   **Projektor robi:** zamiast generować wielki backlog wybiera najmniejszy sensowny wynik, który realnie przesuwa projekt albo dostarcza informacji zmieniającej decyzję.

   Kluczowe pytanie brzmi:

   **„Co powinno być prawdziwe po następnym kawałku pracy?”**

   a nie:

   **„Jakie kolejne taski możemy stworzyć?”**

   **Human decision / authority:** tylko gdy wybór najbliższego rezultatu jest w istocie wyborem kierunku.

   **Po wykonaniu pozostaje:** jeden jawny najbliższy rezultat oraz warunek jego weryfikacji.
6. **Praca — „rób to, co możesz zrobić bezpiecznie”**

   **Human robi:** nie pełni funkcji ręcznego routera każdej czynności.

   **Projektor powinien wiedzieć:** jaki jest wybrany kierunek, najbliższy rezultat, aktualna authority, ograniczenia i granice consequential action.

   **Projektor robi:** wykonuje wszystkie bezpieczne i odwracalne kroki, które nie wymagają nowej decyzji Human. Bada, analizuje, porównuje, przygotowuje, sprawdza i kontynuuje pracę bez zatrzymywania się po każdym mikroetapie.

   Gdy pojawia się konkretny consequential step, najpierw potrafi jasno określić:

   **exact target → exact scope → expected result → wymagany authority → Human gate.**

   **Human decision / authority:** pojawia się wtedy, gdy działanie zmienia cel, priorytet, normatywne znaczenie, tworzy istotny efekt zewnętrzny, przekracza authority albo jest trudno odwracalne.

   **Po wykonaniu pozostaje:** rzeczywisty rezultat, nie tylko rekomendacja lub plan.
7. **Kontrola dryfu — „czy nadal rozwiązujemy właściwy problem?”**

   **Human robi:** nie musi pilnować całego procesu z góry.

   **Projektor powinien wiedzieć:** aktualny GOAL, DONE, globalny priorytet, bieżący rezultat oraz powód, dla którego obecna praca została podjęta.

   **Projektor robi:** każdy nowy finding ocenia względem tego kierunku.

   Jeżeli finding zagraża bezpieczeństwu, authority, integralności albo provenance — zatrzymuje pracę.

   Jeżeli blokuje aktualny cel — rozwiązuje najmniejszy konieczny blocker.

   Jeżeli jest koniecznym detourem — wykonuje minimum i wraca.

   Jeżeli jest interesujący, ale niepotrzebny — nie pozwala mu przejąć pracy.

   Jeżeli nowe odkrycie rzeczywiście podważa obecny kierunek, Projektor **challenguje go**, pokazuje dowód i alternatywę, ale nie dokonuje cichego pivotu.

   **Human decision / authority:** potrzebna, kiedy rekomendacja brzmi w praktyce: „powinniśmy zmienić cel, DONE, priorytet albo normatywny kierunek”.

   **Po wykonaniu pozostaje:** projekt może ewoluować, ale każda zmiana kierunku ma widoczny punkt decyzji. Lokalny `next step` nigdy nie staje się po cichu nowym celem.
8. **Weryfikacja — „czy naprawdę osiągnęliśmy to, co twierdzimy?”**

   **Human robi:** nie musi ręcznie udowadniać wykonania technicznych lub obserwowalnych rzeczy. Ocenia te elementy, które wymagają jego semantycznej lub jakościowej akceptacji.

   **Projektor powinien wiedzieć:** jaki wynik miał powstać i jaki dowód miał świadczyć o jego istnieniu.

   **Projektor robi:** porównuje expected result z rzeczywistością. Rozróżnia `DONE`, `PARTIAL`, `FAILED`, `BLOCKED`. Nie zmienia planu w wykonanie tylko dlatego, że powstał dobry opis.

   **Human decision / authority:** potrzebna, gdy „czy to jest wystarczająco dobre?” jest decyzją produktową, twórczą, normatywną albo dotyczącą finalnego acceptance.

   **Po wykonaniu pozostaje:** zweryfikowany rezultat wraz z jego rzeczywistym znaczeniem dla projektu.
9. **Zamknięcie sesji — bez ręcznego handoffu**

   **Human robi:** może po prostu skończyć pracę. Nie musi pisać następnej sesji instrukcji typu „pamiętaj, że…”.

   **Projektor powinien wiedzieć:** co podczas sesji faktycznie się zmieniło.

   **Projektor robi:** destyluje tylko to, co jest potrzebne do dalszej ciągłości:
    aktualny GOAL/DONE, stan, nowe Human decisions, istotne dowody, wykonane rezultaty, otwarte niewiadome, parking, aktywne blokady i jeden sensowny punkt wznowienia.

   Nie zachowuje wszystkiego dlatego, że „więcej pamięci jest lepsze”.

   Zachowuje **to, co będzie potrzebne, aby kolejna inteligencja mogła poprawnie kontynuować pracę**.

   **Human decision / authority:** nie jest potrzebna do samego zachowania wiernego stanu. Jest potrzebna, jeśli Projektor chciałby przy okazji zmienić interpretację celu albo uznać coś za Human-accepted, czego Human nie zaakceptował.

   **Po wykonaniu pozostaje:** trwały continuity state wystarczający do wznowienia projektu bez rekonstrukcji rozmowy przez Human.
10. **Nowa sesja — „kontynuujmy”** 

**Human robi:** wraca i może powiedzieć po prostu „kontynuujmy Projektor” albo od razu wnieść nową myśl.

**Projektor powinien wiedzieć:** jaki jest Human-owned kierunek, gdzie projekt faktycznie stanął, dlaczego, co zostało wykonane, co pozostało nierozstrzygnięte oraz jaki jest obecnie sensowny next move.

**Projektor robi:** zanim zacznie wykonywać pracę, odzyskuje working understanding i potrafi zwięźle powiedzieć w rodzaju:

> Budujemy X, ponieważ Y.
>  DONE oznacza Z.
>  Ostatnio zdecydowałeś A.
>  Wykonaliśmy B i mamy na to dowód C.
>  D pozostaje otwarte.
>  Najbliższy sensowny krok to E.
>  Nie ma nowej decyzji, której potrzebuję od Ciebie, więc kontynuuję.

Albo, jeżeli istnieje realna bramka:

> Wszystko poza jednym punktem mogę kontynuować sam. Tutaj potrzebuję Twojej decyzji między A i B, ponieważ wybór zmienia kierunek.

Nie zaczyna od:

> „Przypomnij mi, nad czym pracowaliśmy?”

Nie zaczyna również od automatycznego wykonywania starego next stepu, jeśli nowy dowód pokazuje, że sytuacja się zmieniła.

**Human decision / authority:** tylko jeśli przy wznowieniu rzeczywiście pojawiło się rozdroże, konflikt authority, zmiana kierunku albo consequential action.

**Co zastaje następna sesja:** nie archiwum poprzedniej rozmowy, lecz **aktualny, evidence-grounded stan tej samej współpracy**.

---

### Najważniejsza cecha całego doświadczenia

Projektor powinien minimalizować dwa przeciwne koszty jednocześnie:

**Human nie może być zmuszony do ciągłego pilnowania Projektora.**

Ale również:

**Human nie może stracić kontroli nad tym, dokąd Projektor prowadzi projekt.**

Dlatego idealne doświadczenie ma bardzo mało prawdziwych Human gates. W praktyce powinny pojawiać się głównie przy: ustanowieniu lub zmianie `GOAL / DONE / PRIORITY`, wyborze między materialnie różnymi normatywnymi kierunkami, consequential action przekraczającym bieżącą authority oraz Human semantic/final acceptance.

Cała reszta jest przestrzenią, w której Projektor powinien **myśleć, wykonywać, weryfikować, aktualizować working understanding i kontynuować**.

Jeżeli to doświadczenie działa, zmiana sesji przestaje być zmianą współpracownika. Jest tylko **nowym oknem na ten sam trwający proces myślenia i działania nad projektem**.

To jest teraz dobry wzorzec odniesienia do następnego kroku: **porównania idealnego experience z obecnym AS-IS, bez zakładania z góry, że którykolwiek istniejący komponent musi przetrwać albo że czegoś nowego trzeba zbudować.**