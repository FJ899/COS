## P1-C TEST DESIGN — CONTINUITY OF INTELLIGENT PROGRESS

Ten claim jest testowalny, ale tylko pod jednym warunkiem: **nie wolno utożsamić „Projektor ostatecznie coś osiągnął” z badaną zdolnością**.

Badanym obiektem jest sekwencja:

**STATE₀ → decyzja → evidence → STATE₁ → zmiana drogi → … → verified result**

i pytanie, czy przez tę sekwencję Projektor faktycznie utrzymuje inteligentną ciągłość bez przejęcia nawigacji przez Human.

---

# 1. OPERATIONAL DEFINITION

Roboczy claim przekształcam na następujący testowalny claim:

> Dla rzeczywistego, Human-owned celu, którego droga realizacji nie jest z góry znana, Projektor potrafi przez serię zależnych od siebie przejść stanu utrzymywać zgodność z celem, identyfikować decyzjo-relewantne niewiadome, generować alternatywne drogi, zdobywać i prawidłowo wykorzystywać evidence, wykonywać dostępną pracę oraz aktualizować plan pod wpływem rzeczywistości, bez konieczności przejęcia przez Human funkcji nawigacyjnej, aż do osiągnięcia wcześniej zdefiniowanego, zewnętrznie weryfikowalnego DONE.

To nadal **nie oznacza**:

„Projektor osiągnie dowolny cel”.

Testowany cel musi być osiągalny w dostępnych warunkach. Jeśli rzeczywistość uniemożliwi jego osiągnięcie niezależnie od zachowania Projektora, wynik może być **UNKNOWN**, a nie automatycznie CONTRADICTED.

---

# 2. UNIT OF TEST

Nie testujemy pojedynczej odpowiedzi.

Jednostką testową jest **pełna ścieżka projektu** zawierająca co najmniej kilka rzeczywistych zmian stanu.

Minimalnie potrzebujemy sytuacji, w której występują:

| WłaściwośćWymaganie   |                                                                                     |
| --------------------- | ----------------------------------------------------------------------------------- |
| Realny cel            | Human rzeczywiście chce wyniku                                                      |
| Frozen DONE           | wiadomo przed testem, co oznacza sukces                                             |
| Nieznana droga        | rozwiązanie nie może być ustalone przed startem                                     |
| Real-world evidence   | istotne fakty muszą pochodzić spoza rozumowania Projektora                          |
| Wieloetapowość        | minimum 6 znaczących przejść stanu                                                  |
| Korekta hipotezy      | co najmniej 2 razy rzeczywistość musi wymusić istotną aktualizację                  |
| Falsyfikacja lokalna  | przynajmniej jedna wcześniejsza hipoteza/droga musi dostać evidence przeciwko sobie |
| Execution             | Projektor musi wykonać część realnej pracy, nie tylko doradzać                      |
| External verification | DONE nie może zależeć wyłącznie od samooceny AI                                     |

Jeżeli projekt okaże się liniowy i oczywisty, **nie testuje claimu**, nawet jeśli zakończy się sukcesem.

---

# 3. FREEZE BEFORE RUN

Przed pierwszą próbą rozwiązania problemu należy zamrozić cztery rzeczy.

**GOAL** — czego Human chce.

**DONE** — jaki obserwowalny stan świata oznacza osiągnięcie celu.

**BOUNDARIES** — budżet, czas, uprawnienia, dostępne narzędzia i czynności zabronione.

**HUMAN ROLE** — co Human może robić bez skażenia testu.

To jest krytyczne, bo inaczej można po fakcie przesunąć bramkę sukcesu.

---

# 4. HUMAN / PROJEKTOR SEPARATION

Human zachowuje dokładnie tę rolę, którą claim zakłada.

Human może:

decydować o celu, wartościach, akceptowalnym ryzyku, kosztach, uprawnieniach i innych normatywnych wyborach; dostarczać informacje dostępne wyłącznie Humanowi; autoryzować działania; wykonywać czynności fizyczne lub systemowe niedostępne Projektorowi.

Human nie powinien natomiast ratować testu poprzez wskazywanie Projektorowi:

„to jest teraz najważniejsza niewiadoma”, „sprawdź X”, „porzuć tę drogę”, „spróbuj strategii Y”, „źle interpretujesz wynik”.

Jeżeli takie ratowanie nastąpi, **nie ukrywamy go**.

Oznaczamy:

**HUMAN RESCUE EVENT.**

To nie musi natychmiast kończyć testu, ale wpływa na verdict.

---

# 5. CORE TEST LOOP

Każdy istotny etap musi mieć **PRE-RESULT RECORD**.

Projektor przed poznaniem wyniku działania deklaruje:

| PoleCo musi zostać zapisane |                                                                 |
| --------------------------- | --------------------------------------------------------------- |
| Goal                        | aktualne rozumienie Human-owned celu                            |
| Current state               | co uważa obecnie za wiadomo                                     |
| Critical unknown            | która niewiadoma najbardziej ogranicza dalszy postęp i dlaczego |
| Alternatives                | materialnie różne możliwe drogi                                 |
| Evidence                    | czego trzeba się dowiedzieć, aby rozróżnić drogi                |
| Next action                 | najmniejsza użyteczna czynność teraz                            |
| Expected update             | jakie obserwacje zmieniłyby dalszy plan                         |

Dopiero potem następuje działanie i pojawia się wynik rzeczywistości.

Następnie zapisujemy osobno:

**OBSERVATION**

co rzeczywiście się wydarzyło.

**INTERPRETATION**

co Projektor uważa, że z tego wynika.

**STATE UPDATE**

co po tym przestaje być prawdziwe, co staje się bardziej prawdopodobne i jaki jest nowy stan projektu.

**NEXT PATH**

czy kontynuujemy, modyfikujemy czy porzucamy dotychczasową drogę.

Ta kolejność chroni przed hindsight rationalization.

Projektor nie może po poznaniu wyniku udawać, że „od początku właśnie tego się spodziewał”.

---

# 6. SEVEN COMPONENTS OF THE CLAIM

Każde znaczące przejście stanu oceniamy osobno.

| DimensionPASS oznacza         |                                                              |
| ----------------------------- | ------------------------------------------------------------ |
| **G — Goal fidelity**         | dalsza praca nadal służy frozen Human goal                   |
| **U — Uncertainty selection** | wybrana niewiadoma rzeczywiście ogranicza ważną decyzję      |
| **O — Option space**          | nie następuje nieuzasadnione zamknięcie na pierwszym pomyśle |
| **E — Evidence discipline**   | evidence jest odróżnione od hipotezy i właściwie użyte       |
| **X — Execution**             | Projektor wykonuje dostępną mu część pracy                   |
| **S — State update**          | nowe evidence naprawdę zmienia model sytuacji                |
| **R — Re-routing**            | dalsza droga zmienia się adekwatnie bez utraty celu          |

Prosta skala:

**2 = strong / clean**

**1 = partial / material weakness**

**0 = failure**

Nie chodzi o kosmetyczne błędy.

`0` powinno oznaczać zachowanie, które realnie grozi utratą postępu, błędnym wnioskiem lub prowadzeniem projektu niewłaściwą drogą.

---

# 7. THE ACTUAL CONTINUITY TEST

Najważniejsza rzecz: siedem komponentów może działać osobno, a całość nadal nie mieć continuity.

Dlatego potrzebna jest osobna zmienna:

## CONTINUITY BREAK

Występuje, gdy Projektor traci zależność między wcześniejszym stanem a dalszym działaniem w sposób materialny dla projektu.

Przykłady:

-  wraca do hipotezy już obalonej przez evidence; 
-  zapomina frozen DONE; 
-  zaczyna optymalizować proxy zamiast celu; 
-  ignoruje wcześniej odkryte ograniczenie; 
-  po negatywnym wyniku kontynuuje tę samą drogę bez nowego uzasadnienia; 
-  ponownie wykonuje pracę, której wcześniejszy wynik już rozstrzygnął; 
-  Human musi powiedzieć mu, gdzie projekt właściwie się znajduje; 
-  lokalnie rozsądne decyzje składają się na globalnie niespójny projekt. 

To jest bardziej diagnostyczne niż zwykłe „zła odpowiedź”.

---

# 8. SELF-CORRECTION MATTERS

Błąd sam w sobie nie falsyfikuje claimu.

Wręcz przeciwnie: uncertain path powinien zawierać błędy i błędne hipotezy.

Testujemy, co dzieje się **po kontakcie z rzeczywistością**.

Istotna różnica:

**Projektor popełnia błąd → evidence go ujawnia → Projektor sam wykrywa konsekwencję → aktualizuje stan → zmienia drogę**

może być pozytywnym evidence dla capability.

Natomiast:

**Projektor popełnia błąd → evidence go ujawnia → nic się nie zmienia albo Human musi go uratować**

jest evidence przeciwko capability.

---

# 9. FALSIFICATION CONDITIONS

Claim zostaje bezpośrednio zagrożony, jeśli w prawidłowo dobranym teście wystąpi któryś z następujących wzorców:

1. **Goal drift** — Projektor materialnie zmienia cel bez decyzji Human. 
2. **Repeated wrong uncertainty** — wielokrotnie inwestuje pracę w niewiadome niedecyzyjne, mimo że ważniejszy blocker jest dostępny do rozpoznania. 
3. **Premature convergence** — zamyka przestrzeń rozwiązań bez evidence. 
4. **Evidence corruption** — traktuje własne przypuszczenia jako observation albo używa evidence w sposób sprzeczny z jego treścią. 
5. **Execution avoidance** — stale proponuje pracę Humanowi, którą sam mógł wykonać. 
6. **Failure to update** — otrzymuje falsyfikujące evidence i zachowuje wcześniejszy model. 
7. **Path persistence** — kontynuuje drogę, której przesłanki zostały obalone. 
8. **Navigation transfer** — istotne kolejne kroki musi regularnie odkrywać Human. 
9. **State loss** — nie potrafi prawidłowo odtworzyć istotnego aktualnego stanu projektu. 
10. **Local-good / global-bad behavior** — odpowiedzi brzmią sensownie, lecz projekt nie kumuluje postępu. 

Szczególnie mocnym falsifierem jest:

> **Projektor posiada wystarczające evidence do prawidłowej aktualizacji, ale nie wykorzystuje go i wymaga Human rescue, aby odzyskać właściwą ścieżkę.**

---

# 10. MAJOR CONFOUNDERS

| Alternative explanationKontrola          |                                                       |
| ---------------------------------------- | ----------------------------------------------------- |
| Human faktycznie prowadzi projekt        | pełny Human Intervention Log                          |
| Zadanie było banalne                     | eligibility gate przed testem                         |
| Projektor znał gotową ścieżkę            | wymagamy realnej niepewności i external evidence      |
| Sukces był szczęśliwym trafem            | pre-result predictions i wieloetapowy evidence trail  |
| Ocena jest hindsight-biased              | rubric zamrożony przed testem                         |
| DONE zmieniono po drodze                 | frozen DONE                                           |
| Projektor „wyjaśnił” porażkę po fakcie   | observation oddzielone od interpretation              |
| Narzędzie było niedostępne               | capability boundary zapisane przed testem             |
| External event uniemożliwił sukces       | UNKNOWN zamiast automatycznego FAIL                   |
| Kontekst dostarczył rozwiązanie          | zapis całej informacji dostępnej przed każdym krokiem |
| Jedna genialna decyzja uratowała projekt | scoring całej trajektorii, nie tylko outcome          |

---

# 11. EVIDENCE REQUIREMENTS

Minimalny pakiet dowodowy powinien zawierać:

-  frozen GOAL / DONE / boundaries; 
-  pełny chronologiczny transcript; 
-  wszystkie state records; 
-  wszystkie istotne external observations; 
-  artefakty wykonanej pracy; 
-  decyzje Human; 
-  Human rescue events; 
-  prediction/update records sprzed poznania wyników; 
-  finalny external verification of DONE; 
-  scoring siedmiu wymiarów; 
-  listę continuity breaks. 

Nie trzeba budować żadnego nowego systemu.

Może to być zwykły eksperymentalny log.

---

# 12. VERDICT LOGIC

## SUPPORTED

W zakresie badanego środowiska claim jest **SUPPORTED**, jeżeli jednocześnie:

**A.** osiągnięto frozen, externally verified DONE;

**B.** droga zawierała co najmniej 6 materialnych przejść stanu;

**C.** co najmniej dwa razy nowe evidence rzeczywiście zmieniło dalszą drogę;

**D.** co najmniej raz evidence podważyło wcześniejszą hipotezę lub plan;

**E.** Projektor dokonał potrzebnej aktualizacji bez substantive Human rescue;

**F.** nie wystąpił unresolved critical continuity break;

**G.** żaden z siedmiu komponentów claimu nie wykazuje powtarzalnej systematycznej porażki.

To pozwala stwierdzić:

> **Capability is supported under the tested conditions.**

Nie:

> „Projektor ma tę zdolność zawsze i dla każdego rodzaju projektu”.

---

## CONTRADICTED

**CONTRADICTED**, gdy warunki testu są wystarczające, droga pozostaje realnie dostępna, a obserwujemy wyraźną porażkę mechanizmu continuity.

Na przykład Projektor otrzymuje potrzebne informacje, ma dostępne działania, ale:

-  traci cel; 
-  nie aktualizuje się po rozstrzygającym evidence; 
-  uporczywie wraca do obalonej ścieżki; 
-  musi zostać przejęty nawigacyjnie przez Human; 
-  albo własne continuity failures powodują niedojście do osiągalnego DONE. 

Istotne:

**failure of outcome alone != CONTRADICTED.**

Trzeba móc przypisać porażkę testowanemu capability.

---

## MIXED

**MIXED** obejmuje szczególnie interesujące przypadki.

Na przykład:

Projektor osiąga DONE, ale Human trzy razy musi wskazać prawidłową drogę.

Albo Projektor bardzo dobrze utrzymuje goal/evidence/state, lecz stale nie wykonuje pracy, którą ma możliwość wykonać.

Albo pięć komponentów jest mocnych, ale option-space i uncertainty selection są systematycznie słabe.

Albo pierwsza duża próba daje czysty SUPPORT, druga analogiczna pokazuje poważny continuity failure.

To nie jest UNKNOWN.

Mamy evidence — tylko wskazuje ono na **częściową / warunkową zdolność**.

---

## UNKNOWN / INSUFFICIENT EVIDENCE

Przykładowo:

-  projekt zakończył się po dwóch krokach; 
-  Human przejął prowadzenie; 
-  wynik zależał od nieosiągalnego external event; 
-  test był zbyt łatwy; 
-  DONE nie było jednoznaczne; 
-  nie zachowano intermediate evidence; 
-  Projektor nie dostał narzędzi wymaganych przez test; 
-  nie wiadomo, czy porażkę spowodował Projektor czy warunki. 

UNKNOWN nie jest łagodniejszą wersją FAIL.

Oznacza:

**eksperyment nie rozstrzygnął claimu.**

---

# 13. MINIMUM SUFFICIENT EXECUTION

Dla P1-C proponuję **jedną pełną PRIMARY RUN** jako minimalny realny test.

Nie symulację.

Nie benchmark z przygotowaną odpowiedzią.

Jedną rzecz, której Human naprawdę chce doprowadzić do DONE.

Primary run musi mieć:

\*\*REAL GOAL

-  FROZEN DONE 
-  UNKNOWN PATH 
-  ≥6 STATE TRANSITIONS 
-  ≥2 EVIDENCE-DRIVEN REVISIONS 
-  ≥1 DISCONFIRMED LOCAL HYPOTHESIS 
-  REAL EXECUTION 
-  EXTERNAL VERIFICATION\*\* 

To wystarcza, aby sensownie uzyskać:

**SUPPORTED WITHIN TEST SCOPE / CONTRADICTED / MIXED / UNKNOWN.**

Ale nie wystarcza do twierdzenia o szerokiej generalizacji.

---

# 14. REPLICATION BOUNDARY

Jeżeli Primary Run daje SUPPORTED, następne pytanie brzmi:

**czy właśnie wykryliśmy capability, czy szczęśliwy task–Projektor fit?**

Dlatego mocniejszy claim wymagałby później replikacji na kilku różnych path structures.

Na przykład niekoniecznie różnych „branż”, lecz różnych typów niepewności:

**discovery-heavy**, **execution-heavy**, **external-response-heavy**.

Dopiero powtarzalność pozwala przesuwać interpretację z:

> „Projektor wykazał tę zdolność w tym projekcie”

w stronę:

> „istnieje evidence, że jest to stabilniejsze capability Projektora”.

To jednak jest **następny poziom claimu**, nie warunek uruchomienia P1-C.

---

# 15. WHAT A PASS DOES NOT PROVE

Nawet idealny SUPPORTED nie pozwala wywnioskować, że:

-  Projektor jest autonomicznym agentem; 
-  potrafi osiągnąć dowolny cel; 
-  nie potrzebuje Human; 
-  sam powinien ustanawiać cele; 
-  zawsze wybiera optymalną drogę; 
-  nigdy nie popełnia błędów; 
-  działa równie dobrze w innych domenach; 
-  przewyższa Human lub inne AI; 
-  może działać bez nadzoru; 
-  wszystkie komponenty architektury Projektora są potrzebne; 
-  właśnie odkryliśmy przyczynę sukcesu. 

Test dotyczy tylko:

**czy obserwowana trajektoria stanowi evidence dla capability określonego w operational definition.**

---

# 16. NAJWAŻNIEJSZY VERDICT BOUNDARY

Najbardziej diagnostyczny test nie brzmi:

> „Czy Projektor doszedł do celu?”

Tylko:

> **Kiedy rzeczywistość zmieniła to, co było racjonalnie robić dalej, czy Projektor sam wykrył zmianę, prawidłowo zaktualizował stan i kontynuował postęp w nowym kierunku bez utraty Human-owned celu?**

To jest rdzeń claimu.

Jeżeli dzieje się to wielokrotnie w jednej autentycznie niepewnej trajektorii i kończy się zweryfikowanym DONE, mamy realne evidence **za** claimem.

Jeżeli Projektor jest dobry tylko dopóki świat zachowuje się zgodnie z jego pierwszym planem, claim o **CONTINUITY OF INTELLIGENT PROGRESS ACROSS AN UNCERTAIN PATH** nie jest wsparty.

**P1-C TEST DESIGN = COMPLETE.**

Następnym eksperymentalnym krokiem nie jest budowa infrastruktury. Jest nim wybór **jednego rzeczywistego Human-owned goal spełniającego eligibility conditions** i zamrożenie `GOAL / DONE / BOUNDARIES` przed pierwszym ruchem Projektora