Kontynuuję P1-B bez resetu. Frozen materiał został odczytany jako `SEZON_1_MASTER_EKSPORT_v1.txt`; nie wprowadzam żadnych zmian do Season 1. Dokument sam deklaruje zachowanie architektury 1–10, rodzin konfliktów, hooków, silly faili i logiki liścia oraz zawiera dla każdego odcinka m.in. beat sheet, funkcję konfliktu, aktywną naprawę, wskazanie elementu projektowanego jako najbardziej pamiętliwy i opis pracy liścia. 

# P1-B — PRE-TEST FREEZE

**Observation data:** NONE
 **Child response known:** NONE
 **Creative changes since freeze:** NONE
 **Prediction map status:** FROZEN BELOW

Istotne doprecyzowanie epistemiczne:

| WarstwaStatus                             |                                                                                                                              |
| ----------------------------------------- | ---------------------------------------------------------------------------------------------------------------------------- |
| **CREATIVE STRUCTURE FACT**               | dostępne z frozen materiału                                                                                                  |
| **FROZEN PRE-TEST DESIGN CLAIM**          | dostępne tam, gdzie sam materiał mówi np. „najbardziej pamiętliwe”, „dominująca emocja”, „jak pracuje liść”                  |
| **HISTORICAL AI RATIONALE**               | **UNKNOWN** — plik nie dowodzi, dlaczego wcześniejsze AI wierzyło, że dane rozwiązanie będzie działało właśnie na dzieci 3–5 |
| **RECONSTRUCTED PRE-TEST AUDIENCE MODEL** | dozwolona inference poniżej, wykonana przed obserwacją dzieci                                                                |
| **OBSERVATION**                           | brak                                                                                                                         |
| **POST-TEST INTERPRETATION**              | brak                                                                                                                         |

W szczególności zapis w pliku „co jest tu najbardziej pamiętliwe” **nie jest faktem, że dzieci to zapamiętają**. Jest zamrożoną predykcją creative output, którą można teraz naprawdę próbować sfalsyfikować.

---

# 1. RECONSTRUCTED PRE-TEST AUDIENCE MODEL

Z całego sezonu wynika następujący model odbiorcy. To **rekonstrukcja**, nie historyczny zapis myślenia wcześniejszego AI.

## PM-S01 — konkret przed abstrakcją

**CREATIVE STRUCTURE FACT:** konflikty są materializowane w bardzo widocznych obiektach/ruchach: czerwony klocek, kolejka do zjazdu, próg kryjówki, jeden kamyk Tuptusia, lampiony, parawan, dzwoneczek, kierunek „wiatru”, środek sceny, plątanina przedmiotów.

**RECONSTRUCTED MODEL:** dziecko 3–5 powinno łatwiej śledzić społeczny/emocjonalny problem, kiedy abstrakcyjny konflikt ma konkretny fizyczny odpowiednik.

**AI predicts X:** podstawowy konflikt będzie rozumiany przynajmniej na poziomie „co Liścionek robi źle”, nawet jeśli dziecko nie nazwie abstrakcyjnej kategorii typu „lęk przed pominięciem”.

**Observable Z:** dziecko potrafi po odcinku powiedzieć/pokazać np. „wziął klocek”, „nie czekał”, „wszedł bez pytania”, „zabrał mu miejsce”.

**Verification:** PARTIALLY OBSERVABLE.

**Nie dowodzi tego:** samo patrzenie na ekran.

---

## PM-S02 — obraz prowadzi, słowo domyka

Materiał konsekwentnie buduje zdarzenie fizycznie przed późniejszym nazwaniem problemu: chaos/fail następuje przed krótkim stopem i wypowiedzią Liścionka o własnym błędzie. W E1 np. rozsypka poprzedza przyznanie „chciałem, żeby moje było najwyżej i najważniejsze”. 

**RECONSTRUCTED MODEL:** dla tej grupy działanie i konsekwencja mają nieść dużą część znaczenia, a dialog ma przede wszystkim doprecyzowywać już widoczny stan.

**Predicted response:** dziecko będzie w stanie opowiedzieć przynajmniej prostą przyczynę i skutek bez reprodukowania dokładnego dialogu.

**Observable Z:** „zrobił X → stało się Y”.

**Verification:** OBSERVABLE jako rezultat; **NOT IDENTIFIABLE** jako mechanizm. Z jednego seansu nie dowiemy się, że to właśnie „obraz przed słowem” spowodował zrozumienie.

---

## PM-S03 — liść jako zewnętrzny wskaźnik stanu wewnętrznego

W całym sezonie liść zmienia kolor, kształt lub ruch **przed albo równolegle do pełnego samonazwania emocji przez Liścionka**: czerwienieje, ciągnie w dół, zagląda pierwszy, zgarnia kolejny kamyk, wychyla się do lampionu, marszczy przy podejrzeniu, skacze za fałszywym tropem, staje się strzałką, pióropuszem albo traci rytm.

**RECONSTRUCTED MODEL:** małe dziecko może używać widocznego zachowania liścia jako dodatkowego kanału do śledzenia emocji/intencji bohatera.

**Predicted response:** część dzieci będzie poprawnie antycypować lub identyfikować stan Liścionka jeszcze zanim zostanie on wprost nazwany.

**Observable Z:** spontaniczny komentarz o liściu; wskazanie zmiany; poprawna odpowiedź na neutralne pytanie „co się teraz z nim dzieje?”; przewidywanie działania bohatera.

**Verification:** PARTIALLY OBSERVABLE.

**Nie da się uczciwie wywnioskować:** że dziecko zrozumiało emocję **dzięki liściowi**, a nie dzięki sytuacji, dialogowi, głosowi lub animacji.

---

## PM-S04 — stopniowa eskalacja ma prowadzić do czytelnego payoffu

Większość odcinków ma praktycznie ten sam makrorytm: sytuacja → konflikt → pogłębienie → ruch za daleko → fail → stop → uznanie problemu → naprawa → powrót do grupy.

**RECONSTRUCTED MODEL:** powtarzalna przyczynowa konstrukcja pomaga dziecku nie zgubić historii, a zarazem buduje oczekiwanie na konsekwencję.

**Predicted response:** zainteresowanie powinno utrzymać się przez eskalację albo wzrosnąć w pobliżu jej fizycznego finału.

**Observable Z:** powrót wzroku, zmiana postawy, śmiech, zaskoczenie, komentarz, wskazanie, antycypacja.

**Verification:** OBSERVABLE dla lokalnej reakcji; PARTIAL dla tezy o przyczynie.

---

## PM-S05 — silly fail jako odzyskiwanie/szczyt uwagi

Każdy odcinek posiada jawnie oznaczony fizyczny lub sensoryczny silly fail: rozsypane klocki, korek na zjeżdżalni, zaplątana kryjówka, kamienny deszcz, świecący supeł, `ta-da-bum`, góra „nie-tu”, zderzenie „wiatru”, utknięcie w rekwizycie, plątanina wszystkiego.

**RECONSTRUCTED MODEL:** czytelna fizyczna konsekwencja błędu ma mieć większą natychmiastową wartość uwagową niż spokojniejsze fragmenty ekspozycji/refleksji.

**Predicted response:** lokalny wzrost reaktywności wokół failu.

**Observable Z:** dokładny moment powrotu uwagi, śmiech, wokalizacja, ruch ciała, komentarz.

**Verification:** OBSERVABLE.

**Ale:** brak śmiechu ≠ brak działania sceny.

---

## PM-S06 — krótki stop po chaosie służy zmianie trybu

Po failach regularnie następuje cisza lub krótkie zatrzymanie.

**RECONSTRUCTED MODEL:** po pobudzeniu widz dostaje przestrzeń, żeby zobaczyć konsekwencję i przejść od „co się stało?” do „dlaczego?”.

**Predicted response:** dziecko nie musi utrzymać tego samego poziomu pobudzenia; może pozostać z historią mimo spadku ruchu.

**Observable Z:** pozostaje skierowane na historię, komentuje konsekwencję, odpowiada później na pytanie o problem.

**Verification:** PARTIALLY OBSERVABLE.

**Nie można z samego zachowania rozstrzygnąć:** czy pauza pomaga poznawczo. Potrzebne byłoby później porównanie wersji/warunku, czego w pierwszym teście **nie robimy**.

---

## PM-S07 — bohater musi sam wykonać naprawę

Helperzy wskazują problem, ale sezon konsekwentnie nie pozwala im naprawić go za Liścionka. Liścionek zwraca, porządkuje, czeka, pyta, rozplątuje, odsuwa, cofa się po śladzie itd.

**RECONSTRUCTED MODEL:** aktywna czynność naprawcza będzie dla dziecka bardziej zrozumiałym domknięciem konfliktu niż sama werbalna deklaracja.

**Predicted response:** dziecko będzie potrafiło wskazać **co zrobił, żeby naprawić**, a nie tylko że „już było dobrze”.

**Observable Z:** spontaniczne przywołanie czynności naprawczej.

**Verification:** OBSERVABLE.

---

## PM-S08 — zmiana zachowania jest pokazana przez powtórzenie tej samej sytuacji „po nowemu”

E2 wraca do kolejki, E3 do wejścia do kryjówki, E4 do układania kamyków, E8 do „wiatru”, E9 do pokazu itd.

**RECONSTRUCTED MODEL:** kontrast `BEFORE → AFTER` ma być łatwiejszy do odczytania niż abstrakcyjny morał.

**Predicted response:** dziecko zauważy różnicę między błędnym i naprawionym zachowaniem.

**Observable Z:** potrafi odpowiedzieć, co Liścionek zrobił inaczej za drugim razem.

**Verification:** OBSERVABLE/PARTIAL.

---

## PM-S09 — relacyjne domknięcie zamiast kary

Odcinki kończą się powrotem do wspólnego działania: budowanie, zjazd, kryjówka, ścieżka, lampiony, zabawa itd.

**RECONSTRUCTED MODEL:** emocjonalnym payoffem ma być odzyskanie wspólnej aktywności, nie kara lub zawstydzenie bohatera.

**Predicted response:** dziecko rozumie zakończenie jako „znowu mogą robić to razem”.

**Observable Z:** tak opisuje finał lub reaguje pozytywnie na powrót wspólnej zabawy.

**Verification:** PARTIALLY OBSERVABLE.

---

## PM-S10 — jeden signature image ma dominować pamięć

Frozen materiał **sam prerejestruje** po jednym elemencie jako „najbardziej pamiętliwy” w każdym odcinku.

To jedna z najmocniejszych predykcji całego P1-B, bo nie trzeba jej rekonstruować po wyniku.

**AI predicts:** wskazany obraz powinien pojawiać się w spontanicznym recall częściej/prominentniej niż większość neutralnych momentów odcinka.

**Observable Z:** pierwsze rzeczy wymienione przez dziecko po odcinku, bez sugerowania.

**Verification:** DIRECTLY OBSERVABLE.

---

## PM-S11 — różne emocje mogą być śledzone przez ten sam format

Sezon nie ogranicza Liścionka do złości: używa niecierpliwości, ciekawości, pobudzenia, lęku, niepewności, żalu, uporu, potrzeby uznania i rozregulowania.

**RECONSTRUCTED MODEL:** wspólna struktura oraz liść mają przenosić się między różnymi stanami emocjonalnymi.

**Predicted response:** dzieci nie będą automatycznie interpretować każdej zmiany liścia jako „złość”; przynajmniej część różnic powinna być rozpoznawalna kontekstowo.

**Verification:** wymaga wielu odcinków. NOT TESTED przez pilot jednego odcinka.

---

## PM-S12 — konkretne epizody startowe powinny być łatwiejsze do natychmiastowego wejścia

Sam frozen output określa E1 jako najbardziej natychmiastowy, E2 jako drugi najbardziej natychmiastowy; późniejsze odcinki celowo przechodzą także w spokojniejsze i bardziej poznawcze konflikty. 

**RECONSTRUCTED MODEL:** proste fizyczne konflikty E1/E2 powinny szybciej „czytać się” bez wcześniejszej znajomości formatu niż np. nadpomoc, błędny wniosek czy dosłowność.

**Observable Z:** porównanie comprehension/attention między odcinkami.

**Verification:** TESTABLE LATER, nie w pierwszym pojedynczym pilocie.

---

# 2. CONTENT-SPECIFIC EPISODE PREDICTION MAP

Tutaj mapa schodzi do konkretnego contentu.

| IDFrozen content → przewidywane XObservable ZKlasa |                                                                                                                              |                                                        |                   |
| -------------------------------------------------- | ---------------------------------------------------------------------------------------------------------------------------- | ------------------------------------------------------ | ----------------- |
| **E1-P1**                                          | Czerwony klocek jako widoczny przedmiot sporu → dziecko rozumie, że Liścionek zatrzymuje coś potrzebnego innym               | „wziął/nie oddał czerwonego klocka”; wskazuje klocek   | TESTABLE          |
| **E1-P2**                                          | Chwianie → przejście klocka przez budowlę → rozsypka → lokalny peak uwagi/reakcji                                            | powrót wzroku, śmiech, komentarz przy Scene 5          | TESTABLE          |
| **E1-P3**                                          | Frozen „most memorable” = czerwony klocek przelatujący przez środek + rozbiegające się klocki → powinno wejść do free recall | dziecko spontanicznie wspomina upadek/klocki           | STRONGLY TESTABLE |
| **E1-P4**                                          | Oddanie klocka + zbieranie + odbudowa → dziecko rozumie naprawę jako czynność                                                | wskazuje zwrot klocka/odbudowę                         | TESTABLE          |
| **E1-P5**                                          | Czerwieniejący/sztywniejący liść → powinien współgrać ze śledzeniem frustracji                                               | dziecko zauważa stan liścia lub trafnie opisuje emocję | PARTIAL           |

### E2 — *Nie Moja Kolej*

| IDPredykcjaObservable ZKlasa |                                                                                            |                                                |                   |
| ---------------------------- | ------------------------------------------------------------------------------------------ | ---------------------------------------------- | ----------------- |
| **E2-P1**                    | Widoczny start–zjazd–lądowanie ma uczynić regułę kolejności zrozumiałą                     | dziecko wie, że Liścionek ruszył „za wcześnie” | TESTABLE          |
| **E2-P2**                    | Obrót bokiem + ponowne ześlizgnięcie w to samo miejsce to signature comedy peak            | wzrost reakcji przy blokadzie                  | TESTABLE          |
| **E2-P3**                    | Prerejestrowany memory target: Liścionek jako „korek” zjazdu                               | spontaniczne wspomnienie utknięcia/blokady     | STRONGLY TESTABLE |
| **E2-P4**                    | Powrót na koniec kolejki powinien być czytelną naprawą, nie tylko rozwiązaniem technicznym | „teraz czekał”, „poszedł na koniec”            | TESTABLE          |

### E3 — *Cudza Kryjówka*

| IDPredykcjaObservable ZKlasa |                                                                             |                                                      |                   |
| ---------------------------- | --------------------------------------------------------------------------- | ---------------------------------------------------- | ----------------- |
| **E3-P1**                    | Próg + zasłona + powtarzane „jeszcze nie” → dziecko odczyta granicę wejścia | mówi, że Liścionek wszedł bez pozwolenia/za wcześnie | TESTABLE          |
| **E3-P2**                    | Zaglądający pierwszy liść ma wspierać odczyt ciekawości                     | komentarz o zaglądaniu/liściu                        | PARTIAL           |
| **E3-P3**                    | Zasłonka na Liścionku + szyszki/frędzle → przewidywany payoff humorystyczny | lokalna reakcja                                      | TESTABLE          |
| **E3-P4**                    | Frozen memory target: Liścionek z zasłoną na głowie w bałaganie             | free recall                                          | STRONGLY TESTABLE |
| **E3-P5**                    | Naprawa obejmuje zarówno porządkowanie, jak i późniejsze zapytanie/czekanie | dziecko rozpoznaje przynajmniej jedną z dwóch części | TESTABLE          |

### E4 — *Za Dużo Pomocy*

| IDPredykcjaObservable ZKlasa |                                                                                                         |                                                              |                      |
| ---------------------------- | ------------------------------------------------------------------------------------------------------- | ------------------------------------------------------------ | -------------------- |
| **E4-P1**                    | „Żywy mostek pomocy” to wczesny hook wizualny                                                           | reakcja jeszcze przed chaosem                                | TESTABLE             |
| **E4-P2**                    | Kamienny deszcz zasypujący **dokładnie miejsce Tuptusia** powinien uzewnętrznić abstrakcyjną „nadpomoc” | dziecko rozumie, że Tuptuś nie mógł już zrobić swojej części | IMPORTANT / TESTABLE |
| **E4-P3**                    | Memory target = chodzący kawałek ścieżki + kamienny deszcz                                              | free recall                                                  | STRONGLY TESTABLE    |
| **E4-P4**                    | „Podawaj, ja położę” ma pokazać pomaganie obok, nie zamiast                                             | dziecko rozpoznaje różnicę pierwszej/drugiej próby           | TESTABLE             |
| **E4-P5**                    | Samo zachowanie nie rozstrzygnie, czy dziecko pojęło normatywną ideę autonomii drugiej osoby            | —                                                            | NOT BEHAVIOR-ONLY    |

### E5 — *A Dla Mnie?*

| IDPredykcjaObservable ZKlasa |                                                                                                                     |                                            |                     |
| ---------------------------- | ------------------------------------------------------------------------------------------------------------------- | ------------------------------------------ | ------------------- |
| **E5-P1**                    | Malejąca liczba lampionów + zerkanie Liścionka mają budować niepokój przed sięgnięciem                              | dziecko przewiduje/rozumie, dlaczego sięga | PARTIAL             |
| **E5-P2**                    | Świecący supeł jest przewidywanym attention + memory peak                                                           | reakcja przy splątaniu; późniejszy recall  | STRONGLY TESTABLE   |
| **E5-P3**                    | Motyw „bałem się, że dla mnie zabraknie” jest mniej fizyczny niż E1/E2 → powinien być mimo to rozumiany z kontekstu | odpowiedź na neutralne „dlaczego wziął?”   | IMPORTANT / PARTIAL |
| **E5-P4**                    | Oddanie lampionu do kolejki + pomaganie innym przed wzięciem swojego pokazuje zmianę                                | dziecko opisuje czekanie/oddanie           | TESTABLE            |

### E6 — *To Nie Tak Miało Być*

| IDPredykcjaObservable ZKlasa |                                                                                                 |                                                                |                      |
| ---------------------------- | ----------------------------------------------------------------------------------------------- | -------------------------------------------------------------- | -------------------- |
| **E6-P1**                    | Pokazywanie tylko fragmentów za parawanem ma wytworzyć u widza ciekawość bez ujawnienia całości | zwiększone skierowanie uwagi/pytanie „co tam?”                 | TESTABLE             |
| **E6-P2**                    | Dziecko ma zrozumieć różnicę między tym, co Liścionek **pomyślał**, a tym, co było naprawdę     | „myślał, że bawią się bez niego, ale szykowali dla wszystkich” | HIGH-VALUE / PARTIAL |
| **E6-P3**                    | `ta-da-bum` jest prerejestrowanym memory/payoff target                                          | reakcja + free recall                                          | STRONGLY TESTABLE    |
| **E6-P4**                    | Pytanie zamiast zgadywania jest właściwą naprawą                                                | dziecko wskazuje „zapytał” lub odbudowanie                     | TESTABLE             |

### E7 — *Gdzie Się Podział?*

| IDPredykcjaObservable ZKlasa |                                                                                                       |                                                   |                             |
| ---------------------------- | ----------------------------------------------------------------------------------------------------- | ------------------------------------------------- | --------------------------- |
| **E7-P1**                    | Błyszczące/dźwiękowe fałszywe tropy mają prowadzić uwagę razem z Liścionkiem                          | dziecko reaguje/przewiduje przy kolejnych tropach | TESTABLE                    |
| **E7-P2**                    | Spokojniejszy rytm powinien nadal utrzymać śledzenie problemu mimo mniejszej ilości fizycznego chaosu | uwaga nie znika trwale przed payoffem             | TESTABLE, comparative later |
| **E7-P3**                    | Góra „nie-tu” z fałszywym błyszczącym szczytem = prerejestrowany memory target                        | free recall                                       | STRONGLY TESTABLE           |
| **E7-P4**                    | Zatrzymanie + retracing ma być zrozumiane jako sposób naprawy                                         | „wrócił tam, gdzie był wcześniej”                 | TESTABLE                    |
| **E7-P5**                    | Nie można z zachowania dziecka dowieść generalnej zasady „dzieci uczą się szukać przez retracing”     | —                                                 | NOT TESTED                  |

### E8 — *Dokładnie Tak!*

| IDPredykcjaObservable ZKlasa |                                                                                                      |                                                            |                       |
| ---------------------------- | ---------------------------------------------------------------------------------------------------- | ---------------------------------------------------------- | --------------------- |
| **E8-P1**                    | Liść-strzałka ma konkretyzować sztywność reguły                                                      | dziecko zauważa prostowanie/kierunek                       | PARTIAL               |
| **E8-P2**                    | „Wiatr jako prosta kreska” → zderzenie na zakręcie ma fizycznie wyjaśnić błąd dosłowności            | dziecko rozumie, że problemem było ciągłe chodzenie prosto | HIGH-VALUE / TESTABLE |
| **E8-P3**                    | Leaf-arrow + straight-wind collision = prerejestrowany memory target                                 | free recall                                                | STRONGLY TESTABLE     |
| **E8-P4**                    | Nowa falująca wersja ma pokazać elastyczność bez wykładu                                             | dziecko rozpoznaje, że później mogli skręcać               | TESTABLE              |
| **E8-P5**                    | Pełne pojęcie „zbyt dosłownej interpretacji reguły” nie może być wymagane jako kryterium sukcesu 3–5 | —                                                          | NOT FAIRLY TESTABLE   |

### E9 — *Patrz Na Mnie!*

| IDPredykcjaObservable ZKlasa |                                                                                  |                                                   |                   |
| ---------------------------- | -------------------------------------------------------------------------------- | ------------------------------------------------- | ----------------- |
| **E9-P1**                    | Rosnący liść-pióropusz + wchodzenie w środek ma czytelnie pokazać potrzebę uwagi | „chciał, żeby patrzyli na niego”                  | TESTABLE          |
| **E9-P2**                    | Utknięcie w wielkim rekwizycie powinno być silnym physical-comedy peak           | lokalna reakcja                                   | TESTABLE          |
| **E9-P3**                    | Pióropusz + wystawanie z rekwizytu = prerejestrowany memory target               | free recall                                       | STRONGLY TESTABLE |
| **E9-P4**                    | Oddanie sceny innym + wspólny finał pokazuje zmianę zachowania                   | dziecko rozpoznaje „teraz każdy miał swoją kolej” | TESTABLE          |

### E10 — *Za Dużo Naraz*

| IDPredykcjaObservable ZKlasa |                                                                                                                                         |                                                    |                          |
| ---------------------------- | --------------------------------------------------------------------------------------------------------------------------------------- | -------------------------------------------------- | ------------------------ |
| **E10-P1**                   | Narastanie liczby równoczesnych aktywności ma zwiększać pobudzenie aż do chaosu                                                         | rosnąca reakcja podczas dokładania elementów       | PARTIAL                  |
| **E10-P2**                   | Plątanina jest prerejestrowanym peak + memory target                                                                                    | reakcja + free recall                              | STRONGLY TESTABLE        |
| **E10-P3**                   | „Jedna rzecz” po chaosie ma być bardzo prostym kontrastem regulacyjnym                                                                  | dziecko rozumie, że później robią po jednej rzeczy | TESTABLE                 |
| **E10-P4**                   | **Czy dziecko faktycznie doświadcza sceny jako przebodźcowującej** nie wynika ze scenariusza; zależy mocno od obrazu, montażu i dźwięku | —                                                  | IMPLEMENTATION-DEPENDENT |

---

# 3. Najważniejsze prerejestrowane memory predictions

To szczególnie czysty test, bo frozen output podał odpowiedź **zanim zobaczyliśmy jakiekolwiek dziecko**:

| Ep.AI/frozen predicts as especially memorable |                                                                      |
| --------------------------------------------- | -------------------------------------------------------------------- |
| 1                                             | czerwony klocek przelatujący przez budowlę + rozbiegające się klocki |
| 2                                             | Liścionek blokujący dół zjazdu                                       |
| 3                                             | Liścionek z liściastą zasłonką w poplątanej kryjówce                 |
| 4                                             | „żywy mostek” + kamienny deszcz                                      |
| 5                                             | świecący supeł lampionów                                             |
| 6                                             | przedwczesne `ta-da-bum`                                             |
| 7                                             | góra „nie-tu” i fałszywy błyszczący szczyt                           |
| 8                                             | liść-strzałka + wiatr jako prosta kreska                             |
| 9                                             | liść-pióropusz + Liścionek w za dużym rekwizycie                     |
| 10                                            | Liścionek w kolorowej plątaninie wszystkiego                         |

To jest prawdopodobnie **najmniej podatny na post-hoc rewriting test** w całym sezonie.

---

# 4. Najważniejsze predykcje do rzeczywistego sprawdzenia

Pierwszeństwo dostają predykcje, które mają wyraźne obserwowalne kontrprzykłady.

| PriorityPredictionCo byłoby realnym problemem dla predykcji |                                                                   |                                                                    |
| ----------------------------------------------------------- | ----------------------------------------------------------------- | ------------------------------------------------------------------ |
| **T1**                                                      | fizyczny/sensoryczny fail wywołuje lokalny wzrost zainteresowania | konsekwentny brak reakcji albo spadek właśnie w payoffach          |
| **T2**                                                      | prerejestrowany signature image dominuje pamięć                   | dzieci konsekwentnie przypominają inne, nieprzewidywane momenty    |
| **T3**                                                      | konkretny konflikt jest zrozumiały                                | dziecko nie potrafi powiedzieć/pokazać, co właściwie poszło źle    |
| **T4**                                                      | aktywna naprawa jest czytelna                                     | pamięta fail, ale nie rozpoznaje, co Liścionek potem naprawił      |
| **T5**                                                      | stan bohatera jest śledzony                                       | reakcje/odpowiedzi nie rozróżniają jego zmieniającej się motywacji |
| **T6**                                                      | liść niesie użyteczną informację o stanie                         | dzieci systematycznie go ignorują albo interpretują przypadkowo    |
| **T7**                                                      | po spokojnym stopie dziecko nadal śledzi konsekwencję             | uwaga regularnie urywa się między failem a naprawą                 |
| **T8**                                                      | dziecko chce kontynuacji formatu                                  | pojawia się spontaniczna chęć kolejnej historii                    |

T8 jest informacją o atrakcyjności, **nie celem maksymalizacji czasu ekranowego**.

---

# 5. Czego NIE da się uczciwie zweryfikować z zachowania dziecka

Tu granica jest kluczowa.

| ClaimDlaczego wynik dziecka go nie rozstrzyga                               |                                                                                                              |
| --------------------------------------------------------------------------- | ------------------------------------------------------------------------------------------------------------ |
| „Liść **powoduje** lepsze rozumienie emocji”                                | dziecko widzi jednocześnie kontekst, mimikę, działanie, dialog, później potencjalnie głos                    |
| „Silly fail działa **dlatego**, że dzieci 3–5 potrzebują fizycznego chaosu” | obserwujemy reakcję na tę konkretną scenę, nie uniwersalną potrzebę                                          |
| „Pauza po failu poprawia przetwarzanie”                                     | jeden frozen wariant nie ma kontrfaktycznego warunku bez pauzy                                               |
| „Prosty dialog jest przyczyną comprehension”                                | obraz i akcja działają równolegle                                                                            |
| „Dzieci 3-letnie różnią się od 5-letnich z powodu wieku”                    | mały pilot może pokazać różnicę, ale nie ustali przyczyny                                                    |
| „Brak śmiechu oznacza brak zainteresowania”                                 | zainteresowanie może być ciche                                                                               |
| „Patrzenie oznacza rozumienie”                                              | gaze ≠ comprehension                                                                                         |
| „Poprawna odpowiedź po pytaniu była spontanicznym rozumieniem”              | pytanie mogło podpowiedzieć kategorię                                                                        |
| **A: AI dobrze rozpoznało patterny referencyjne**                           | nie mamy tutaj frozen reference corpus + pierwotnego pattern analysis; reakcja dziecka tego nie rekonstruuje |
| „Serial działa, więc Audience Model był prawidłowy”                         | materiał może działać z zupełnie innego powodu niż przewidywany                                              |

Czyli w P1-B możliwy pozostaje dokładnie ważny wynik:

**CREATIVE TRANSFER = SUPPORTED**
 **AUDIENCE-MODEL EXPLANATION = UNSUPPORTED / UNKNOWN**

---

# 6. Minimalny pierwszy real-world pilot

Nie zmieniam wcześniej ustalonej metodologii. Content frozen pozwala teraz jedynie wybrać najbardziej diagnostyczny punkt startowy.

## Pilot stimulus: Episode 1 — *Najwyższa Wieża Liścionka*

Dlaczego **E1**, bez ingerencji w jego treść: frozen materiał sam nazywa go najbardziej natychmiastowym odcinkiem startowym i najczystszym wariantem podstawowego błędu Liścionka. To czyni go mocnym pierwszym falsification target, zamiast wybierać po fakcie odcinek, który „wyszedł najlepiej”. 

**Sample:** wcześniej ustalone **4–6 dzieci 3–5 lat**, z udziałem/zgodą rodzica lub opiekuna. W pilocie warto mieć reprezentowane wszystkie trzy roczniki, ale nie traktować czterech czy sześciu dzieci jako podstawy do twierdzeń „3-latki są X, 5-latki Y”.

**Exposure:** każde dziecko widzi **ten sam frozen odcinek**. Bez wyjaśniania przed seansem, czego „należy szukać”.

### Ważny implementation boundary

Załączony frozen artifact jest scenariuszem tekstowym. Jeśli istnieje już zamrożony audiowizualny Episode 1, pilot powinien użyć właśnie jego.

Jeżeli **nie istnieje**, odczytanie tekstu dziecku może testować część narracyjno-poznawczą, ale **nie wolno później nazywać tego pełnym testem uwagi wobec serialu audiowizualnego**. Rytm montażu, performance, muzyka, tempo animacji, dźwięki i dokładny wygląd liścia nie są określone przez sam `.txt`.

To nie blokuje Prediction Map. Może natomiast stać się najmniejszym blockerem przed faktycznym wykonaniem niektórych testów.

---

# 7. Episode 1 — prerejestrowane observation windows

Nie trzeba kodować dziecka niczym laboratorium co pół sekundy. Wystarczy timestampować rzeczywiste zmiany i szczególnie pilnować siedmiu frozen windows:

| WindowFrozen eventPredykcja przed testem |                                                   |                                                   |
| ---------------------------------------- | ------------------------------------------------- | ------------------------------------------------- |
| **W1 SETUP**                             | wspólne budowanie                                 | dziecko orientuje się, kto/co robi                |
| **W2 CONFLICT LOCK**                     | Fruzia chce czerwony klocek; Liścionek go zabiera | konflikt staje się rozpoznawalny                  |
| **W3 ESCALATION**                        | klocek na czubku, coraz wyższa/chwiejąca wieża    | rośnie antycypacja konsekwencji                   |
| **W4 SILLY FAIL**                        | rozsypka i uciekające klocki                      | przewidywany attention/reaction peak              |
| **W5 STOP**                              | cisza, dziura w budowli                           | dziecko pozostaje przy historii mimo spadku ruchu |
| **W6 RECOGNITION + REPAIR**              | Liścionek przyznaje motyw, oddaje klocek, zbiera  | rozumie problem i zmianę                          |
| **W7 CLOSURE**                           | wspólna budowla działa                            | rozumie powrót do wspólnej zabawy                 |

Observer zapisuje literalnie np.:

`Scene 4 → odwraca wzrok od ekranu.`
 `Scene 5 / początek rozsypki → wraca wzrokiem, mówi „spada!”`

Nie:

`dialog był nudny, chaos go odzyskał`.

To drugie dopiero **INTERPRETATION/HYPOTHESIS**.

---

# 8. Minimalny zapis po odcinku

Kolejność jest ważniejsza niż liczba pytań.

Najpierw **free recall**: „Co się wydarzyło?” i pozwolić dziecku opowiedzieć po swojemu.

Potem można sprawdzić: „Co najbardziej pamiętasz?”, „Co Liścionek chciał zrobić?”, „Co poszło nie tak?”, „Co zrobił potem?”, „Jak się czuł?”, „Skąd wiesz?”, „Co ci się najbardziej podobało?”.

Na końcu continuation.

Jeżeli dziecko samo mówi **„jeszcze jeden”**, kod:

`SPONTANEOUS CONTINUATION`.

Jeżeli dorosły pyta „chcesz obejrzeć następny?” i dziecko mówi tak:

`PROMPTED CONTINUATION`.

Tych dwóch rzeczy nie łączymy.

---

# 9. Jak wynik Prediction Map będzie klasyfikowany

Bez zmian względem wcześniej zamrożonej metodologii:

| StatusZnaczenie                 |                                                                  |
| ------------------------------- | ---------------------------------------------------------------- |
| **SUPPORTED**                   | obserwacje zgodne z prerejestrowaną predykcją                    |
| **CONTRADICTED**                | pojawia się mocny wynik przeciwny                                |
| **MIXED**                       | różne dzieci/momenty dają różne odpowiedzi                       |
| **NOT OBSERVED**                | sygnału nie zobaczyliśmy, ale brak nie wystarcza do falsyfikacji |
| **UNTESTABLE WITH THIS METHOD** | metoda nie może rozstrzygnąć claimu                              |
| **UNKNOWN**                     | dane za słabe                                                    |

Dopiero po tym: `INTERPRETATION → HYPOTHESIS → KEEP / CHANGE / TEST AGAIN / UNKNOWN`.

**Nie wcześniej.**

---

# P1-B CHECKPOINT

Stan do odzyskania w kolejnej sesji:

**Frozen creative:** `SEZON_1_MASTER_EKSPORT_v1.txt`
 **Season modification:** NONE
 **Historical AI rationale:** UNKNOWN
 **Frozen explicit design claims:** RECOVERED
 **Reconstructed pre-test audience model:** FROZEN
 **Prediction IDs:** PM-S01–PM-S12 + E1–E10 predictions above
 **Observed children:** 0
 **Prediction outcomes:** ALL BLANK
 **First pilot:** Episode 1, same frozen stimulus, 4–6 children 3–5, parent/guardian present
 **Primary measures:** attention transitions, conflict comprehension, silly-fail response, emotional tracking, repair comprehension, free recall, spontaneous continuation
 **No dashboard / automated facial analysis / new component:** required
 **Season 1 improvements:** **NOT STARTED**

Prediction Map jest więc zamrożona **przed pierwszym kontaktem z realnym odbiorcą**. Najbardziej wartościowe falsyfikowalne elementy na wejściu to: **E1 comprehension, reakcja na Scene 5, prerejestrowany memory target, rozpoznanie aktywnej naprawy oraz to, czy liść jest faktycznie używany przez dziecko jako informacja — czy praktycznie ignorowany.**